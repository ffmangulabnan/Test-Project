package com.utilities;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;

import com.webdriver.AesCipher;

import java.awt.Color;
import javax.swing.JPasswordField;
import javax.swing.JCheckBox;

@SuppressWarnings("serial")
public class ConfigUI extends JDialog {
	private final JPanel contentPanel = new JPanel();
	private JTextField textName;
	private JTextField textHost;
	private JTextField textUser;
	private JPasswordField passwordField;
	private JTextField textDbName;
	private JPasswordField passwordField_1;
	/**
	 * Create the dialog.
	 */
	public ConfigUI(ConfigDB dbConfig,AesCipher aesCipher,String status) {
		String machineName = dbConfig.getConfigValue("machineName");
		String host = dbConfig.getConfigValue("host");
		String user = dbConfig.getConfigValue("user");
		String password = aesCipher.decrypt(dbConfig.getConfigValue("password")).toString();
		String serverDB = dbConfig.getConfigValue("serverDB");
		String machineKey = aesCipher.decrypt(dbConfig.getConfigValue("machineKey")).toString();
		String headless =  dbConfig.getConfigValue("headless");
		
		setAlwaysOnTop(true);
		setResizable(false);
		setModal(true);
		setBounds(100, 100, 331, 365);
		getContentPane().setLayout(null);
		contentPanel.setBounds(0, 0, 325, 304);
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel);
		contentPanel.setLayout(null);
		{
			JLabel lblName = new JLabel("Name:");
			lblName.setBounds(20, 11, 46, 14);
			contentPanel.add(lblName);
		}
		{
			textName = new JTextField(machineName);
			textName.setBounds(87, 8, 219, 20);
			contentPanel.add(textName);
			textName.setColumns(10);
		}
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(Color.LIGHT_GRAY));
		panel.setBounds(20, 74, 286, 138);
		contentPanel.add(panel);
		panel.setLayout(null);
		
		JLabel lblHost = new JLabel("Host:");
		lblHost.setBounds(10, 11, 46, 14);
		panel.add(lblHost);
		
		textHost = new JTextField(host);
		textHost.setBounds(94, 11, 171, 20);
		panel.add(textHost);
		textHost.setColumns(10);
		
		JLabel lblUser = new JLabel("User:");
		lblUser.setBounds(10, 42, 46, 14);
		panel.add(lblUser);
		
		textUser = new JTextField(user);
		textUser.setBounds(94, 42, 171, 20);
		panel.add(textUser);
		textUser.setColumns(10);
		
		JLabel lblPassword = new JLabel("Password:");
		lblPassword.setBounds(10, 73, 72, 14);
		panel.add(lblPassword);
		
		passwordField = new JPasswordField(password);
		passwordField.setBounds(94, 73, 171, 20);
		panel.add(passwordField);
		
		JLabel lblDbName = new JLabel("DB Name:");
		lblDbName.setBounds(10, 104, 72, 14);
		panel.add(lblDbName);
		
		textDbName = new JTextField(serverDB);
		textDbName.setBounds(94, 104, 171, 20);
		panel.add(textDbName);
		textDbName.setColumns(10);
		
		JLabel lblPassword_2 = new JLabel("Password:");
		lblPassword_2.setBounds(20, 39, 72, 14);
		contentPanel.add(lblPassword_2);
		
		passwordField_1 = new JPasswordField(machineKey);
		passwordField_1.setBounds(87, 39, 219, 20);
		contentPanel.add(passwordField_1);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new LineBorder(Color.LIGHT_GRAY));
		panel_1.setBounds(20, 223, 286, 70);
		contentPanel.add(panel_1);
		panel_1.setLayout(null);
		
		JCheckBox chckbxHeadlessBrowser = new JCheckBox("Headless Browser");
		chckbxHeadlessBrowser.setSelected(Boolean.parseBoolean(headless));
		chckbxHeadlessBrowser.setBounds(6, 7, 145, 23);
		panel_1.add(chckbxHeadlessBrowser);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setBounds(0, 304, 325, 33);
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane);
			{
				JButton okButton = new JButton("OK");
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						if(status.contentEquals("Stop")) {
							JOptionPane.showMessageDialog(contentPanel, "Stop server first before changing the settings.", "Error", JOptionPane.ERROR_MESSAGE);
							return;
						}
						String machineNameNEW = textName.getText();
						String hostNEW = textHost.getText();
						String userNEW = textUser.getText();
						String passwordNEW = new String(passwordField.getPassword());
						String serverDBNEW = textDbName.getText();
						String machineKeyNEW = new String(passwordField_1.getPassword());
						String headlessNEW =  "false";
						if (chckbxHeadlessBrowser.isSelected()) {
							headlessNEW = "true";
						}
						if(!machineName.contentEquals(machineNameNEW)) {
							//System.out.println(machineName +":"+ machineNameNEW);
							dbConfig.updateConfigValue("machineName",machineNameNEW);
						}
						if(!machineKey.contentEquals(machineKeyNEW)) {
							//System.out.println(machineKey +":"+ machineKeyNEW);
							dbConfig.updateConfigValue("machineKey",aesCipher.encrypt(machineKeyNEW).toString());
						}
						if(!host.contentEquals(hostNEW)) {
							//System.out.println(host +":"+ hostNEW);
							dbConfig.updateConfigValue("host",hostNEW);					
						}
						if(!user.contentEquals(userNEW)) {
							//System.out.println(user +":"+ userNEW);
							dbConfig.updateConfigValue("user",userNEW);
						}
						if(!password.contentEquals(passwordNEW)) {
							//System.out.println(password +":"+ passwordNEW);
							dbConfig.updateConfigValue("password",aesCipher.encrypt(passwordNEW).toString());
						}
						if(!serverDB.contentEquals(serverDBNEW)) {
							//System.out.println(serverDB +":"+ serverDBNEW);
							dbConfig.updateConfigValue("serverDB",serverDBNEW);
						}
						if(!headless.contentEquals(headlessNEW)) {
							dbConfig.updateConfigValue("headless",headlessNEW);
						}
						dispose();
					}
				});
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						dispose();
					}
				});
			}
		}
	}
}
