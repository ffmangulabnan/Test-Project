package com.utilities;

import org.apache.log4j.Logger;
import org.apache.log4j.Level;
import org.apache.log4j.PatternLayout;
import org.apache.log4j.RollingFileAppender;

public class ServerLog {
	private Logger log;
	public ServerLog(String logFile){
		String logName = logFile;
		RollingFileAppender fa = new RollingFileAppender();
		//fa.setLayout(new PatternLayout("%d{dd MM yyyy HH:mm:ss} %5p %c{1}:%L %t - %m%n"));
		//fa.setLayout(new PatternLayout("[%d{dd MM yyyy HH:mm:ss}]%5p[%t] - %m%n"));
		fa.setLayout(new PatternLayout("[%d{HH:mm:ss}]%5p[%t] - %m%n"));
		fa.setFile(logName);
		fa.setAppend(false);
		fa.activateOptions();
		fa.setName(logName);
		fa.setThreshold(Level.DEBUG);
		Logger.getRootLogger().addAppender(fa);
		log = Logger.getLogger(logName);
		log.setAdditivity(false);
		log.addAppender(fa);
	}
	public Logger getLogger(){
		return this.log;
	}

}
