package com.utilities;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;

import javax.swing.JTextArea;

public class LogConsole {
	private String appPath = new File("").getAbsolutePath();
	public LogConsole(JTextArea txtLogs){
		try {
			String logFileName = appPath+"/log/server.log";
			File f = new File(logFileName);
			while (!f.exists()) {
				Thread.sleep(2000);
			}
			Thread logThread = new Thread(new Runnable() {
				public void run() {
					try {
						readLogs(logFileName, txtLogs);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			});
			logThread.start();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	public void readLogs(String filename, JTextArea logs)
			throws InterruptedException, IOException {
		boolean canBreak = false;
		String line;
		try {
			FileReader rdr = new FileReader(filename);
			LineNumberReader lnr = new LineNumberReader(rdr);
			while (!canBreak) {
				line = lnr.readLine();
				if (line == null) {
					Thread.sleep(1000);
					continue;
				}
				logs.append(line + "\n");
				logs.setCaretPosition(logs.getDocument().getLength());
				
			}
			lnr.close();
			rdr.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	
}
