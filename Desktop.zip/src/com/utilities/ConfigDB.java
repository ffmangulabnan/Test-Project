package com.utilities;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ConfigDB {
	private Connection dbConn = null;
	private String appPath = new File("").getAbsolutePath();
	public ConfigDB() {
		dbConn = connect();
	}
	// connect to database
	public Connection connect() {

		Connection c = null;
		try {
			Class.forName("org.sqlite.JDBC");
			// connect to database
			c = DriverManager.getConnection("jdbc:sqlite:"+appPath+"\\cfg\\config.db");
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			// System.exit(0);
		}
		return c;

	}
	public String getConfigValue(String cfgName) {
		List<String[]> recent = executeSelectQuery("SELECT VALUE FROM CONFIG WHERE NAME='" + cfgName + "'");
		for (String[] array : recent) {
			return array[0];
		}
		return "";
	}
	public void updateConfigValue(String name, String value) {
		value = ((value == null) ? "" : value).replaceAll("'", "''");
		executeUpdateQuery("UPDATE config set value='"+value+"' WHERE name='"+name+"';");
	}
	public List<String[]> executeSelectQuery(String sql) {

		Statement stmt = null;
		try {
			stmt = dbConn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);

			ResultSetMetaData rsmd = rs.getMetaData();
			int col = rsmd.getColumnCount();
			List<String[]> modules = new ArrayList<String[]>();

			while (rs.next()) {
				String[] row = new String[col];
				for (int i = 0; i < col; i++) {
					row[i] = rs.getString(i + 1);
				}
				modules.add(row);
			}
			stmt.close();
			return modules;
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
		}
		return null;
	}

	public void executeUpdateQuery(String sql) {
		try {

			Statement stmt = dbConn.createStatement();
			stmt.executeUpdate(sql);
			stmt.close();

		} catch (Exception e) {
			System.out.println(e.getClass().getName() + ": " + e.getMessage());
		}
	}
}
