package com.utilities;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.JOptionPane;

import com.webdriver.AesCipher;

/***********************************
 * mySql Database Connection and All database process
 * author: Francis Mangulabnan
 * Date created: 2/11/2018
 * Last update:
 ************************************/
public class MySqlDB {
	private static ConfigDB dbConfig = new ConfigDB();
	//private EncryptDecrypt encryptObject = new EncryptDecrypt();
	private AesCipher aesCipher = new AesCipher();
	public Connection conn = null;
	private String mySqlDBHostname = dbConfig.getConfigValue("host");
	private String mySqlDBPort = dbConfig.getConfigValue("port");
	public String mySqlUser = dbConfig.getConfigValue("user");
	public String mySqlPass = aesCipher.decrypt(dbConfig.getConfigValue("password")).toString();
	private String serverDB = dbConfig.getConfigValue("serverDB");
	private String mySqlDB = "//"+mySqlDBHostname+":"+mySqlDBPort+"/"+serverDB;
	
	private Statement statement = null;
    private static ResultSet resultSet = null;
   
    public MySqlDB(){
    	dataBaseConnect();
    }
	public void dataBaseConnect(){
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql:" + mySqlDB,mySqlUser,mySqlPass);
		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Error connecting to database!", "Error",JOptionPane.ERROR_MESSAGE);
			conn = null;
			//System.exit(0);
		}
	}
	/***********************************
	 * mySql Get Machine server status
	 * author: Francis Mangulabnan
	 * Date created: 2/11/2018
	 * Last update:
	 ************************************/
	public String getMachineStatus(String name){
		try {
			statement = conn.createStatement();
			resultSet = statement.executeQuery("select * from machine_tbl where name='"+name+"';");
			if(resultSet.next()){
				String status = resultSet.getString("status");
				return status;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "Not Found";
	}
	public String getResultKey(){
		return aesCipher.decrypt(getConfigValue("resultUploadApiKey")).toString();
	}
	/***********************************
	 * mySql Get Test Suite in-queue
	 * author: Francis Mangulabnan
	 * Date created: 4/14/2018
	 * Last update:
	 ************************************/
	public List<Map<String, String>> getTestSuiteInQueue(String name){
		
		List<Map<String, String>> sts = executeSelectQuery("select * from queuing_tbl where machine='"+name+"' and scheduled='yes' order by date_created asc;");
		if(sts.size() > 0) {
			for (Map<String, String> ts : sts) {
				try {
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
					Date start = sdf.parse(ts.get("start_date"));
					Date end = sdf.parse(ts.get("end_date"));
					Date date = new Date();
					Date today = sdf.parse(sdf.format(date));
					if((today.before(end) || end.equals(today))) {
						 if ((today.after(start) || start.equals(today))) {
							 if(ts.get("frequency").equalsIgnoreCase("daily")) {
								 SimpleDateFormat time = new SimpleDateFormat("HH:mm");
								 Date timeStart = time.parse(ts.get("run_start"));
								 Date timeToday = time.parse(time.format(date));
								 if (timeToday.after(timeStart) || timeStart.equals(timeToday)) {
									 if(ts.get("run_flag").contentEquals("0")) {
										 updateRunQueueRunFlag("1",ts.get("id"));
										 return scheduledTestSuite(ts.get("id"));
									 }
								 }else {
									 if(ts.get("run_flag").contentEquals("1")) {
										 updateRunQueueRunFlag("0",ts.get("id"));
									 }
								 }
							 } else if(ts.get("frequency").equalsIgnoreCase("weekly")) {
								 String[] day = ts.get("run_start").split(" ", 2);
								 if((new SimpleDateFormat("EEEE").format(date)).equalsIgnoreCase(day[0])) {
									 SimpleDateFormat time = new SimpleDateFormat("HH:mm");
									 Date timeStart = time.parse(day[1]);
									 Date timeToday = time.parse(time.format(date));
									 if ((timeToday.after(timeStart) || timeStart.equals(timeToday)) ) {
										 if(ts.get("run_flag").contentEquals("0")) {
											 updateRunQueueRunFlag("1",ts.get("id"));
											 return scheduledTestSuite(ts.get("id"));
										 }
									 } 
								 } else {
									 if(ts.get("run_flag").contentEquals("1")) {
										 updateRunQueueRunFlag("0",ts.get("id"));
									 }
								 }
							 } else if(ts.get("frequency").equalsIgnoreCase("monthly")) {					 
								 String[] day = ts.get("run_start").split(" ", 2);
								 if((new SimpleDateFormat("dd").format(date)).equalsIgnoreCase(day[0])) {
									 SimpleDateFormat time = new SimpleDateFormat("HH:mm");
									 Date timeStart = time.parse(day[1]);
									 Date timeToday = time.parse(time.format(date));

									 if ((timeToday.after(timeStart) || timeStart.equals(timeToday))) {
										 if(ts.get("run_flag").contentEquals("0")) {
											updateRunQueueRunFlag("1",ts.get("id"));
											return scheduledTestSuite(ts.get("id"));
										 }
									 } 
								 } else {
									 if(ts.get("run_flag").contentEquals("1")) {
										 updateRunQueueRunFlag("0",ts.get("id"));
									 }
								 }
							 }
					     }
					} else {
						//delete expired scheduled run
						deleteQueue(ts.get("id"));
					}
					
				}catch (ParseException e) {
					e.printStackTrace();
				}
			}
		}
		
		return executeSelectQuery("select * from queuing_tbl where machine='"+name+"' and scheduled='no' order by date_created asc limit 1;");

	}
	/***********************************
	 * mySql Update run flag
	 * author: Francis Mangulabnan
	 * Date created: 6/28/2018
	 * Last update:
	 ************************************/
	private void updateRunQueueRunFlag(String flag,String id){
		executeUpdateQuery("update queuing_tbl set run_flag='"+flag+"',last_run=sysdate() where id ='"+id+"';");
	}
	/***********************************
	 * mySql return testSuite
	 * author: Francis Mangulabnan
	 * Date created: 6/28/2018
	 * Last update:
	 ************************************/
	private List<Map<String, String>> scheduledTestSuite(String id){
		return executeSelectQuery("select * from queuing_tbl where id ='"+id+"';");
	}
	/***********************************
	 * mySql Get machine
	 * author: Francis Mangulabnan
	 * Date created: 4/14/2018
	 * Last update:
	 ************************************/
	public List<Map<String, String>> getMachine(String name){
		return executeSelectQuery("select * from machine_tbl where name='"+name+"';");
	}
	/***********************************
	 * mySql update status in machine_tbl
	 * author: Francis Mangulabnan
	 * Date created: 2/11/2018
	 * Last update:
	 ************************************/
	public int updateMachineStatus(String name,String status){
		try {
			if(!conn.isClosed()){
				statement = conn.createStatement();
				return statement.executeUpdate("update machine_tbl set status='"+status+"', last_update=sysdate(),"
						+ "update_by='"+System.getProperty("user.name")+"'"
						+ " where name = '"+name+"';");
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return -1;
	}
	/***********************************
	 * mySql Check if project/test run exist
	 * author: Francis Mangulabnan
	 * Date created: 2/11/2018
	 * Last update:
	 ************************************/
	public boolean isTestRunExist(String projId, String runId){
		try {
			statement = conn.createStatement();
			resultSet = statement.executeQuery("select db_name from projects_tbl where id = '"+projId+"';");
			if(resultSet.next()){
				String dbName = resultSet.getString("db_name");
				Connection projConn = DriverManager.getConnection("jdbc:mysql://"+mySqlDBHostname+"/"+dbName,mySqlUser,mySqlPass);
				Statement stmt = projConn.createStatement();
				ResultSet res = stmt.executeQuery("select * from tr_tbl where id = '"+runId+"';");
				if(res.next()){
					projConn.close();
					stmt.close();
					res.close();
					return true;
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	/***********************************
	 * get project db name from projects_tbl
	 * author: Francis Mangulabnan
	 * Date created: 2/21/2018
	 * Last update:
	 ************************************/
	public String getProjectDBName(String projId){
		try {
			statement = conn.createStatement();
			resultSet = statement.executeQuery("select db_name from projects_tbl where id = '"+projId+"';");
			if(resultSet.next()){
				return resultSet.getString("db_name");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	/***********************************
	 * Delete TestSuite from Queuing table
	 * author: Francis Mangulabnan
	 * Date created: 4/13/2018
	 * Last update:
	 ************************************/
	public void deleteQueue(String trId) {
		executeUpdateQuery("delete from queuing_tbl where id ='"+trId+"';");
	}
	/***********************************
	 * Execute Select Mysql query and convert result to list
	 * author: Francis Mangulabnan
	 * Date created: 2/21/2018
	 * Last update:
	 ************************************/
	public List<Map<String, String>> executeSelectQuery(String sql) {

		Statement stmt = null;
		try {
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);

			ResultSetMetaData rsmd = rs.getMetaData();
			int col = rsmd.getColumnCount();
			List<Map<String, String>> listMap = new ArrayList<Map<String, String>>();
			while (rs.next()) {
				Map<String, String> map = new HashMap<String, String>();
				for (int i = 1; i <= col; i++) {
					String name = rsmd.getColumnName(i);
					String value = String.valueOf(rs.getObject(name));
					map.put(name, value);
				}
				listMap.add(map);
			}
			stmt.close();
			return listMap;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	/***********************************
	 * Execute Update Mysql query
	 * author: Francis Mangulabnan
	 * Date created: 2/22/2018
	 * Last update:
	 ************************************/
	public void executeUpdateQuery(String sql) {
		try {
			if(!conn.isClosed()){
				Statement stmt = conn.createStatement();
				stmt.executeUpdate(sql);
				stmt.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/***********************************
	 * mySql Get Machine server status
	 * author: Francis Mangulabnan
	 * Date created: 2/11/2018
	 * Last update:
	 ************************************/
	public String getConfigValue(String name){
		try {
			if(!conn.isClosed()){
				statement = conn.createStatement();
				resultSet = statement.executeQuery("select value from config_tbl where name='"+name+"';");
				if(resultSet.next()){
					String value = resultSet.getString("value");
					return value;
				}
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "Not Found";
	}
}
