package com.webdriver;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;


/***********************************
 * All Actions keywords
 * author: Francis Mangulabnan
 * Date created: 2/24/2018
 * Last update:
 ************************************/
public class ActionDriver {
	private Logger log;
	private ElementLocator locator;
	private WebDriver webDriver;
	private Screenshot screenCapture;
	public Map<String, String> testData = new HashMap<String, String>();
	public Map<String, String> testDataEncrypted = new HashMap<String, String>();
	private AesCipher aesCipher = new AesCipher();
	public ActionDriver(Logger logger,WebDriver wd){
		log = logger;
		webDriver = wd;
		locator = new ElementLocator(log,webDriver);
		screenCapture = new Screenshot(log,webDriver);
	}
	public String[] executeAction(Map<String, String> step,Map<String, String> tc,String fileDir) {
		String[] result = new String[3];
		String action = step.get("action");
		log.info("Executing Action:" + action);
		try {
			locator.webElement = null;
			step = evaluateTestData(step);
			Method selAction = this.getClass().getDeclaredMethod(action, Map.class);
			result = (String[]) selAction.invoke(this, (Object) step);
			if ((step.get("capture").equalsIgnoreCase("Y") || result[0].equalsIgnoreCase("failed")) && currentPageExist()) {
				result[2] = screenCapture.screenCapture(step, fileDir, tc.get("sort") +"-"+ tc.get("name"), result);
			}
			//remove highlight element
			locator.removeHighlight();
		} catch (Exception e) {
			result[0] = "Failed";
			result[1] = e.getMessage();
			e.printStackTrace();
			log.error("Failed to create action:" + result[1]);
		}
		return result;
	}
	/***********************************
	 * Evaluate test data and element string, replace all parameter name with true value
	 * author: Francis Mangulabnan
	 * Date created: 2/25/2018
	 * Last update:
	 ************************************/
	public Map<String, String> evaluateTestData(Map<String, String> step) {
		DataGenerator dataGen = new DataGenerator();
		try {
			step.put("td_value_log", step.get("td_value"));
			if(step.get("td_type").equalsIgnoreCase("password")){
				testDataEncrypted.put(step.get("td_name"),"Y");
				log.info("Decrypting encrypted test data value...");
				step.put("td_value", aesCipher.decrypt(step.get("td_value")).toString());
				step.put("td_value_log", "(encrypted)");
			} else if(step.get("td_type").equalsIgnoreCase("Auto-Generated Date")) {
				log.info("Auto-Generated Date test data value...");
				step.put("td_value", dataGen.generateDate(step.get("td_value")).toString());
				step.put("td_value_log", step.get("td_value"));
			} else if(step.get("td_type").equalsIgnoreCase("Auto-Generated Data")) {
				log.info("Auto-Generated String test data value...");
				step.put("td_value", dataGen.generateString(step.get("td_value")).toString());
				step.put("td_value_log", step.get("td_value"));
			} 
			//evaluating testdata value, replacing testdata name with saved testData
			Pattern pattern = Pattern.compile("\\(%(.*?)%\\)");
			try {
				Matcher matcher = pattern.matcher(step.get("td_value"));
				while (matcher.find()) {
					String match = matcher.group(1);
					if(testDataEncrypted.get(match) != null && testDataEncrypted.get(match).contentEquals("Y")) {
						step.put("td_value_log",step.get("td_value_log").replaceAll("\\(%" + match + "%\\)", "(encrypted)"));
					} else{
						step.put("td_value_log", step.get("td_value_log").replaceAll("\\(%" + match + "%\\)", escapeMetaCharacters(testData.get(match))));
					}
					step.put("td_value", step.get("td_value").replaceAll("\\(%" + match + "%\\)", escapeMetaCharacters(testData.get(match))));
				}	
			} catch (Exception e) {
				// do nothing
			}
			//set testdata name and value to testData map
			testData.put(step.get("td_name"), step.get("td_value"));
			log.info("Testdata Value:" + step.get("td_value_log"));
			
			//evaluating element string, replacing testdata name with saved testData
			String elemString = step.get("el_string");
			step.put("el_string_log", elemString);
			try {
				Matcher matcher = pattern.matcher(elemString);
				while (matcher.find()) {
					String match = matcher.group(1);
					if(testDataEncrypted.get(match) != null && testDataEncrypted.get(match).contentEquals("Y")) {
						elemString = elemString.replaceAll("\\(%" + match + "%\\)", "(encrypted)");
						step.put("el_string_log",elemString);
					} else{
						step.put("el_string_log", step.get("el_string_log").replaceAll("\\(%" + match + "%\\)", escapeMetaCharacters(testData.get(match))));
					}
					step.put("el_string", step.get("el_string").replaceAll("\\(%" + match + "%\\)", escapeMetaCharacters(testData.get(match))));
				}	
			} catch (Exception e) {
				// do nothing
			}
			log.info("Element String:" + step.get("el_string_log"));		
		} catch (Exception e) {
			log.error("Error generating parameter true value:" + e.getMessage());
		}
		return step;
	}
	/***********************************
	 * Replace all defined special char with escape meta characters
	 * author: Francis Mangulabnan
	 * Date created: 2/25/2018
	 * Last update:
	 ************************************/
	public String escapeMetaCharacters(String inputString) {
		final String[] metaCharacters = { "\\", "^", "$", "{", "}", "[", "]", "(", ")", ".", "*", "+", "?", "|", "<",
				">", "-", "&" };
		String outputString = "";
		for (int i = 0; i < metaCharacters.length; i++) {
			outputString = inputString.replace(metaCharacters[i], "\\" + metaCharacters[i]);
			inputString = outputString;
		}
		return outputString;
	}
	/***********************************
	 * check if current page still exist
	 * author: Francis Mangulabnan
	 * Date created: 2/25/2018
	 * Last update:
	 ************************************/
	public boolean currentPageExist() {
		String handle = "";
		try {
			handle = webDriver.getWindowHandle();
		} catch (Exception e) {
			return false;
		}

		for (String winHandle : webDriver.getWindowHandles()) {
			if (handle.contentEquals(winHandle)) {
				return true;
			}
		}
		log.info("Current page closed.");
		return false;
	}

	/*******************************************************************
	 * KEYWORDS
	 *******************************************************************/

	/***********************************
	 * declare param name and stored param value in variable
	 * author: Francis Mangulabnan
	 * Date created: 2/24/2018
	 * Last update:
	 ************************************/
	public String[] declareVar(Map<String, String> step) {
		String[] arrStepStatus = new String[3];
		try {

			if (step.get("td_name") != null && step.get("td_name").length() > 0) {
				testData.put(step.get("td_name"), step.get("td_value"));
				arrStepStatus[0] = "Passed";
				arrStepStatus[1] = "parameter value stored to variable " + step.get("td_name") + ":" + step.get("td_value_log");
			} else {
				log.info("Parameter name is required.");
				arrStepStatus[0] = "Failed";
				arrStepStatus[1] = "Parameter name Empty.";
			}

		} catch (Exception e) {
			arrStepStatus[0] = "Failed";
			arrStepStatus[1] = e.getMessage();
		}
		return arrStepStatus;
	}
	/***********************************
	 * Load URL to active window
	 * author: Francis Mangulabnan
	 * Date created: 2/24/2018
	 * Last update:
	 ************************************/
	public String[] openWebPage(Map<String, String> step) {
		String[] arrStepStatus = new String[3];
		try {
			log.info("web driver: " + webDriver);
			webDriver.get(step.get("td_value"));
			arrStepStatus[0] = "Passed";
			arrStepStatus[1] = "URL navigated to " + step.get("td_value_log");
		} catch (Exception e) {
			arrStepStatus[0] = "Failed";
			arrStepStatus[1] = e.getMessage();
		}
		return arrStepStatus;
	}

	/***********************************
	 *sendkeys to element
	 * author: Francis Mangulabnan
	 * Date created: 2/24/2018
	 * Last update:
	 ************************************/
	public String[] sendkeys(Map<String, String> step) {
		String[] arrStepStatus = new String[3];
		try {
			WebElement element = locator.findElement(step);
			if(element == null) {
				arrStepStatus[0] = "Failed";
				arrStepStatus[1] = locator.elementError;
				return arrStepStatus;
			}

			element.sendKeys(step.get("td_value"));
			arrStepStatus[0] = "Passed";
			arrStepStatus[1] = "Element input: " + step.get("td_value_log");

			
		} catch (Exception e) {
			arrStepStatus[0] = "Failed";
			arrStepStatus[1] = e.getMessage();
		}
		return arrStepStatus;
	}
	/***********************************
	 * Clear textfield then sendkeys to element
	 * author: Francis Mangulabnan
	 * Date created: 2/24/2018
	 * Last update:
	 ************************************/
	public String[] clearsendkeys(Map<String, String> step) {
		String[] arrStepStatus = new String[3];
		try {
			WebElement element = locator.findElement(step);
			if(element == null) {
				arrStepStatus[0] = "Failed";
				arrStepStatus[1] = locator.elementError;
				return arrStepStatus;
			}
			element.click();
		    element.sendKeys(Keys.chord(Keys.CONTROL, "a"));
		    element.sendKeys(Keys.BACK_SPACE);
			//element.clear();
			element.sendKeys(step.get("td_value"));
			arrStepStatus[0] = "Passed";
			arrStepStatus[1] = "Clear + Element input: " + step.get("td_value_log");

			
		} catch (Exception e) {
			arrStepStatus[0] = "Failed";
			arrStepStatus[1] = e.getMessage();
		}
		return arrStepStatus;
	}
	/***********************************
	 * Clear textfield then sendkeys to element then Enter
	 * author: Francis Mangulabnan
	 * Date created: 2/24/2018
	 * Last update:
	 ************************************/
	public String[] clearsendkeysEnter(Map<String, String> step) {
		String[] arrStepStatus = new String[3];
		try {
			WebElement element = locator.findElement(step);
			if(element == null) {
				arrStepStatus[0] = "Failed";
				arrStepStatus[1] = locator.elementError;
				return arrStepStatus;
			}
			element.click();
		    element.sendKeys(Keys.chord(Keys.CONTROL, "a"));
		    element.sendKeys(Keys.BACK_SPACE);
			//element.clear();
			element.sendKeys(step.get("td_value"));
			element.sendKeys(Keys.ENTER);
			arrStepStatus[0] = "Passed";
			arrStepStatus[1] = "Clear + Element input: " + step.get("td_value_log") + " + ENTER";

			
		} catch (Exception e) {
			arrStepStatus[0] = "Failed";
			arrStepStatus[1] = e.getMessage();
		}
		return arrStepStatus;
	}
	/***********************************
	 * Click web Element
	 * author: Francis Mangulabnan
	 * Date created: 2/24/2018
	 * Last update:
	 ************************************/
	public String[] click(Map<String, String> step) {
		String[] arrStepStatus = new String[3];
		try {
			String tdVal = step.get("td_value");
			WebElement element = locator.findElement(step);
			if(element == null) {
				arrStepStatus[0] = "Failed";
				arrStepStatus[1] = locator.elementError;
				return arrStepStatus;
			}

			if (tdVal != null && tdVal.length() > 0) {
				log.info("click with param.");
				element.findElement(By.xpath(".//*[text()='" + tdVal + "']")).click();
			} else {
				locator.findElement(step).click();
			}
			arrStepStatus[0] = "Passed";
			arrStepStatus[1] = "Element clicked.";


		} catch (Exception e) {
			arrStepStatus[0] = "Failed";
			arrStepStatus[1] = e.getMessage();
		}
		return arrStepStatus;
	}
	/***********************************
	 * Double click web element using javascript
	 * author: Francis Mangulabnan
	 * Date created: 2/24/2018
	 * Last update:
	 ************************************/
	public String[] doubleClick(Map<String, String> step) {
		String[] arrStepStatus = new String[3];
		try {
			WebElement element = locator.findElement(step);
			if(element == null) {
				arrStepStatus[0] = "Failed";
				arrStepStatus[1] = locator.elementError;
				return arrStepStatus;
			}
			String mouseOverScript = " triggerMouseEvent(arguments[0], 'dblclick');"
					+ " triggerMouseEvent(arguments[0], 'focus');" + " function triggerMouseEvent (node, eventType) {"
					+ "  var eventObj = document.createEvent ('MouseEvents');"
					+ " eventObj.initEvent (eventType, true, true);" + " node.dispatchEvent (eventObj);" + " }";
			((JavascriptExecutor) webDriver).executeScript(mouseOverScript, element);

			log.info("Doubled clicked.");
			arrStepStatus[0] = "Passed";
			arrStepStatus[1] = "Element double clicked";

		} catch (Exception e) {
			arrStepStatus[0] = "Failed";
			arrStepStatus[1] = e.getMessage();
		}
		return arrStepStatus;
	}
	/***********************************
	 * Mouse over web element using javascript
	 * author: Francis Mangulabnan
	 * Date created: 2/24/2018
	 * Last update:
	 ************************************/
	public String[] mouseHover(Map<String, String> step) {
		String[] arrStepStatus = new String[3];
		try {
			WebElement element = locator.findElement(step);
			if(element == null) {
				arrStepStatus[0] = "Failed";
				arrStepStatus[1] = locator.elementError;
				return arrStepStatus;
			}

			String mouseOverScript = " triggerMouseEvent(arguments[0], 'mouseover');"
					+ " triggerMouseEvent(arguments[0], 'mousemove');"
					+ " function triggerMouseEvent (node, eventType) {"
					+ "  var eventObj = document.createEvent ('MouseEvents');"
					+ " eventObj.initEvent (eventType, true, true);" + " node.dispatchEvent (eventObj);" + " }";
			((JavascriptExecutor) webDriver).executeScript(mouseOverScript, element);

			log.info("Mouse hovered.");

			arrStepStatus[0] = "Passed";
			arrStepStatus[1] = "Mouse over web element.";

			
		} catch (Exception e) {
			arrStepStatus[0] = "Failed";
			arrStepStatus[1] = e.getMessage();
		}

		return arrStepStatus;
	}
	/***********************************
	 * Execute javascript to web driver
	 * author: Francis Mangulabnan
	 * Date created: 2/24/2018
	 * Last update:
	 ************************************/
	public String[] executeJavascript(Map<String, String> step) {
		String[] arrStepStatus = new String[3];
		try {
			String tdVal = step.get("td_value");
			if (tdVal != null && tdVal.length() > 0) {
				log.info("Execute Javascript : " + tdVal);

				String rtrn = (String) ((JavascriptExecutor) webDriver).executeScript(tdVal);
	
				log.info("Javascript return: " + rtrn);
				testData.put(step.get("td_name"), rtrn);
				
				arrStepStatus[0] = "Passed";
				arrStepStatus[1] = "Javascript executed.: " + rtrn;
			} else {
				arrStepStatus[0] = "Failed";
				arrStepStatus[1] = "No javascript found in test data value";
			}
		} catch (Exception e) {
			arrStepStatus[0] = "Failed";
			arrStepStatus[1] = e.getMessage();
		}

		return arrStepStatus;
	}
	/***********************************
	 * key press ENTER and send to web element
	 * author: Francis Mangulabnan
	 * Date created: 2/25/2018
	 * Last update:
	 ************************************/
	public String[] keyPressEnter(Map<String, String> step) {
		String[] arrStepStatus = new String[3];
		try {
			WebElement element = locator.findElement(step);
			if(element == null) {
				arrStepStatus[0] = "Failed";
				arrStepStatus[1] = locator.elementError;
				return arrStepStatus;
			}

			if (step.get("td_value") != null && step.get("td_value").length() > 0) {
				for(int i = 0; i < Integer.parseInt(step.get("td_value")); i++) {
					element.sendKeys(Keys.ENTER);
					log.info("Enter Key pressed.");
				}
			}else {
				element.sendKeys(Keys.ENTER);
				log.info("Enter Key pressed.");
			}
			arrStepStatus[0] = "Passed";
			arrStepStatus[1] = "Enter Key pressed.";

		} catch (Exception e) {
			arrStepStatus[0] = "Failed";
			arrStepStatus[1] = e.getMessage();
		}
		return arrStepStatus;
	}
	/***********************************
	 * key press PAGE UP and send to web element
	 * author: Francis Mangulabnan
	 * Date created: 2/25/2018
	 * Last update:
	 ************************************/
	public String[] keyPressPageUp(Map<String, String> step) {
		String[] arrStepStatus = new String[3];
		try {
			WebElement element = locator.findElement(step);
			if(element == null) {
				arrStepStatus[0] = "Failed";
				arrStepStatus[1] = locator.elementError;
				return arrStepStatus;
			}

			if (step.get("td_value") != null && step.get("td_value").length() > 0) {
				for(int i = 0; i < Integer.parseInt(step.get("td_value")); i++) {
					element.sendKeys(Keys.PAGE_UP);
					log.info("PAGE UP Key pressed.");
				}
			}else {
				element.sendKeys(Keys.PAGE_UP);
				log.info("PAGE UP Key pressed.");
			}
			arrStepStatus[0] = "Passed";
			arrStepStatus[1] = "PAGE UP Key pressed.";

			
			
		} catch (Exception e) {
			arrStepStatus[0] = "Failed";
			arrStepStatus[1] = e.getMessage();
		}
		return arrStepStatus;
	}
	/***********************************
	 * key press PAGE DOWN and send to web element
	 * author: Francis Mangulabnan
	 * Date created: 2/25/2018
	 * Last update:
	 ************************************/
	public String[] keyPressPageDown(Map<String, String> step) {
		String[] arrStepStatus = new String[3];
		try {
			WebElement element = locator.findElement(step);
			if(element == null) {
				arrStepStatus[0] = "Failed";
				arrStepStatus[1] = locator.elementError;
				return arrStepStatus;
			}
			if (step.get("td_value") != null && step.get("td_value").length() > 0) {
				for(int i = 0; i < Integer.parseInt(step.get("td_value")); i++) {
					element.sendKeys(Keys.PAGE_DOWN);
					log.info("PAGE DOWN Key pressed.");
				}
			}else {
				element.sendKeys(Keys.PAGE_DOWN);
				log.info("PAGE DOWN Key pressed.");
			}
			arrStepStatus[0] = "Passed";
			arrStepStatus[1] = "PAGE DOWN Key pressed.";
			
		} catch (Exception e) {
			arrStepStatus[0] = "Failed";
			arrStepStatus[1] = e.getMessage();
		}
		return arrStepStatus;
	}
	/***********************************
	 * key press ESCAPE and send to web element
	 * author: Francis Mangulabnan
	 * Date created: 2/25/2018
	 * Last update:
	 ************************************/
	public String[] keyPressESC(Map<String, String> step) {
		String[] arrStepStatus = new String[3];
		try {
			WebElement element = locator.findElement(step);
			if(element == null) {
				arrStepStatus[0] = "Failed";
				arrStepStatus[1] = locator.elementError;
				return arrStepStatus;
			}
			if (step.get("td_value") != null && step.get("td_value").length() > 0) {
				for(int i = 0; i < Integer.parseInt(step.get("td_value")); i++) {
					element.sendKeys(Keys.ESCAPE);
					log.info("ESCAPE Key pressed.");
				}
			}else {
				element.sendKeys(Keys.ESCAPE);
				log.info("ESCAPE Key pressed.");
			}
			arrStepStatus[0] = "Passed";
			arrStepStatus[1] = "ESCAPE Key pressed.";

			
		} catch (Exception e) {
			arrStepStatus[0] = "Failed";
			arrStepStatus[1] = e.getMessage();
		}
		return arrStepStatus;
	}
	/***********************************
	 * clear Text field
	 * author: Francis Mangulabnan
	 * Date created: 2/25/2018
	 * Last update:
	 ************************************/
	public String[] clearTextField(Map<String,String> step) {
		String[] arrStepStatus = new String[3];
		try {
			WebElement element = locator.findElement(step);
			if(element == null) {
				arrStepStatus[0] = "Failed";
				arrStepStatus[1] = locator.elementError;
				return arrStepStatus;
			}
			//element.clear();
			element.click();
		    element.sendKeys(Keys.chord(Keys.CONTROL, "a"));
		    element.sendKeys(Keys.BACK_SPACE);
			log.info("Text field cleared.");
			arrStepStatus[0] = "Passed";
			arrStepStatus[1] = "Text field cleared.";
			
		} catch (Exception e) {
			arrStepStatus[0] = "Failed";
			arrStepStatus[1] = e.getMessage();
		}

		return arrStepStatus;
	}
	/***********************************
	 * validate displayed text of the specific element
	 * author: Francis Mangulabnan
	 * Date created: 2/25/2018
	 * Last update:
	 ************************************/
	public String[] validateText(Map<String,String> step) {
		String[] arrStepStatus = new String[3];
		try {
			WebElement element = locator.findElement(step);
			if(element == null) {
				arrStepStatus[0] = "Failed";
				arrStepStatus[1] = locator.elementError;
				return arrStepStatus;
			}
			String strElemText = element.getText();
			strElemText = strElemText.replaceAll("\\r\\n|\\r|\\n", " ");
			strElemText = strElemText.trim();

			if (strElemText.contentEquals(step.get("td_value"))) {
				arrStepStatus[0] = "Passed";
				arrStepStatus[1] = "Actual: " + strElemText + " = Expected: " + step.get("td_value_log");
				log.info("Actual: " + strElemText);
				log.info("Actual and Expected are the same.");
			} else {
				arrStepStatus[0] = "Failed";
				arrStepStatus[1] = "[Not Equal] Actual: " + strElemText + " <> Expected: " + step.get("td_value_log");
				log.info("[Not Equal] Actual: " + strElemText + " <> Expected: " + step.get("td_value_log"));
			}


		} catch (Exception e) {
			arrStepStatus[0] = "Failed";
			arrStepStatus[1] = e.getMessage();
		}

		return arrStepStatus;
	}
	/***********************************
	 * validate displayed text contains of the specific element
	 * author: Francis Mangulabnan
	 * Date created: 2/25/2018
	 * Last update:
	 ************************************/
	public String[] validateTextContains(Map<String,String> step) {
		String[] arrStepStatus = new String[3];
		try {
			WebElement element = locator.findElement(step);
			if(element == null) {
				arrStepStatus[0] = "Failed";
				arrStepStatus[1] = locator.elementError;
				return arrStepStatus;
			}

			String strElemText = element.getText();
			strElemText = strElemText.replaceAll("\\r\\n|\\r|\\n", " ");
			strElemText = strElemText.trim();

			Pattern pattern = Pattern.compile("(" + step.get("td_value") + ")");
			Matcher matcher = pattern.matcher(strElemText);
			if (matcher.find()) {
				arrStepStatus[0] = "Passed";
				arrStepStatus[1] = "Actual: " + strElemText + " = Expected: " + step.get("td_value_log");
				log.info("Actual and Expected are Matched. Text Found :" + strElemText + "Matched to:" + step.get("td_value_log"));
			} else {
				arrStepStatus[0] = "Failed";
				arrStepStatus[1] = "[Not Equal] Actual: " + strElemText + " <> Expected: " + step.get("td_value_log");
				log.info("[Not Equal] Actual: " + strElemText + " <> Expected: " + step.get("td_value_log"));
			}

			
		} catch (Exception e) {
			arrStepStatus[0] = "Failed";
			arrStepStatus[1] = e.getMessage();
		}

		return arrStepStatus;
	}
	/***********************************
	 * validate Test data parameter if contains
	 * author: Francis Mangulabnan
	 * Date created: 2/25/2018
	 * Last update:
	 ************************************/
	public String[] valParamContains(Map<String,String> step) {
		String[] arrStepStatus = new String[3];
		try {
			String[] param = step.get("td_value").split("\\|");
			Pattern pattern = Pattern.compile("(" + param[0] + ")");
			Matcher matcher = pattern.matcher(param[1]);
			if (matcher.find()) {
				arrStepStatus[0] = "Passed";
				arrStepStatus[1] = "Regex found Matched: " + step.get("td_value_log");
				log.info("Regex found Matched: " + step.get("td_value_log"));
			} else {
				arrStepStatus[0] = "Failed";
				arrStepStatus[1] = "Regex NOT found Matched: " + step.get("td_value_log");
				log.info("Regex found Matched: " + step.get("td_value_log"));
			}
		} catch (Exception e) {
			arrStepStatus[0] = "Failed";
			arrStepStatus[1] = e.getMessage();
		}

		return arrStepStatus;
	}
	/***********************************
	 * Get URL and saved to td_name runtime variable
	 * author: Francis Mangulabnan
	 * Date created: 2/25/2018
	 * Last update:
	 ************************************/
	public String[] getURL(Map<String,String> step) {
		String[] arrStepStatus = new String[3];
		try {
			if (step.get("td_name") != null && step.get("td_name").length() > 0) {
				String strURL = webDriver.getCurrentUrl();
				testData.put(step.get("td_name"), strURL);
				arrStepStatus[0] = "Passed";
				arrStepStatus[1] = "URL text stored to variable " + step.get("td_name") + ":" + testData.get(step.get("td_name"));
			} else {
				arrStepStatus[0] = "Failed";
				arrStepStatus[1] = "Parameter name is required.";
			}
		} catch (Exception e) {
			arrStepStatus[0] = "Failed";
			arrStepStatus[1] = e.getMessage();
		}

		return arrStepStatus;
	}
	/***********************************
	 * Get URL and saved to td_name runtime variable
	 * author: Francis Mangulabnan
	 * Date created: 2/25/2018
	 * Last update:
	 ************************************/
	public String[] getText(Map<String,String> step) {
		String[] arrStepStatus = new String[3];
		try {
			WebElement element = locator.findElement(step);
			if(element == null) {
				arrStepStatus[0] = "Failed";
				arrStepStatus[1] = locator.elementError;
				return arrStepStatus;
			}
			if (step.get("td_name") != null && step.get("td_name").length() > 0) {
				String strElemText = element.getText();
				testData.put(step.get("td_name"), strElemText);
				arrStepStatus[0] = "Passed";
				arrStepStatus[1] = "URL text stored to variable " + step.get("td_name") + ":" + testData.get(step.get("td_name"));
			} else {
				arrStepStatus[0] = "Failed";
				arrStepStatus[1] = "Parameter name is required.";
			}
		} catch (Exception e) {
			arrStepStatus[0] = "Failed";
			arrStepStatus[1] = e.getMessage();
		}

		return arrStepStatus;
	}
	/***********************************
	 * Get element attribute td_name runtime variable
	 * author: Francis Mangulabnan
	 * Date created: 2/25/2018
	 * Last update:
	 ************************************/
	public String[] getAttValToVar(Map<String,String> step) {
		String[] arrStepStatus = new String[3];
		try {
			WebElement element = locator.findElement(step);
			if(element == null) {
				arrStepStatus[0] = "Failed";
				arrStepStatus[1] = locator.elementError;
				return arrStepStatus;
			}
			
			
			if (step.get("td_value") != null && step.get("td_value").length() > 0) {
				String[] paramArr = step.get("td_value").split("\\|", 2);
				String strElemText = "";

				if (paramArr.length > 1) {
					strElemText = element.getAttribute(paramArr[0]);
					Pattern pattern = Pattern.compile(paramArr[1]);
					Matcher matcher = pattern.matcher(strElemText);
					try {
						strElemText="";
						while (matcher.find()) {
							strElemText = strElemText + matcher.group(1);
						}
						log.info("RegEx Matched:  " + strElemText);
					} catch (Exception n) { }

				} else {
					strElemText = element.getAttribute(step.get("td_value"));
				}

				strElemText = strElemText.replaceAll("\\r\\n|\\r|\\n", " ");
				strElemText = strElemText.trim();
				log.info("Get Element text: " + strElemText);
				
				testData.put(step.get("td_name"), strElemText);
				arrStepStatus[0] = "Passed";
				arrStepStatus[1] = "Element text stored to variable " + step.get("td_name") + ":" + testData.get(step.get("td_name"));
			} else {
				log.info("Element attribute not found.");
				arrStepStatus[0] = "Failed";
				arrStepStatus[1] = "Element attribute not found.";
			}
		} catch (Exception e) {
			arrStepStatus[0] = "Failed";
			arrStepStatus[1] = e.getMessage();
		}
		return arrStepStatus;
	}
	/***********************************
	 * get window handler of current window and stored in variable
	 * author: Francis Mangulabnan
	 * Date created: 2/25/2018
	 * Last update:
	 ************************************/
	public String[] getWindowHandle(Map<String,String> step) {
		String[] arrStepStatus = new String[3];
		try {
			
			if (step.get("td_name") != null && step.get("td_name").length() > 0) {
				String winHandle = webDriver.getWindowHandle();
				log.info("Current Window Handle:  " + winHandle);
				testData.put(step.get("td_name"), winHandle);
				arrStepStatus[0] = "Passed";
				arrStepStatus[1] = "Window handle stored to variable " + step.get("td_name") + ":" + testData.get(step.get("td_name"));
			} else {
				arrStepStatus[0] = "Failed";
				arrStepStatus[1] = "Parameter name is required.";
			}
		} catch (Exception e) {
			arrStepStatus[0] = "Failed";
			arrStepStatus[1] = e.getMessage();
		}
		return arrStepStatus;
	}

	/***********************************
	 * Switch to window handle
	 * author: Francis Mangulabnan
	 * Date created: 2/25/2018
	 * Last update:
	 ************************************/
	public String[] switchToWindow(Map<String,String> step) {
		String[] arrStepStatus = new String[3];
		try {
			if (step.get("td_value") != null && step.get("td_value").length() > 0) {
				log.info("Switch to Window Handle : " + step.get("td_name_log"));
				webDriver.switchTo().window(step.get("td_value"));
				log.info("Successful switch to window handle : " + step.get("td_name_log"));
				arrStepStatus[0] = "Passed";
				arrStepStatus[1] = "Successful switch to window handle :" + step.get("td_name_log");
			} else {
				arrStepStatus[0] = "Failed";
				arrStepStatus[1] = "Window handle is required";
				log.info("Window handle is required");
			}
		} catch (Exception e) {
			arrStepStatus[0] = "Failed";
			arrStepStatus[1] = e.getMessage();
		}

		return arrStepStatus;
	}
	/***********************************
	 * Switch to window newly opened
	 * author: Francis Mangulabnan
	 * Date created: 2/25/2018
	 * Last update:
	 ************************************/
	public String[] switchToNewWindow(Map<String,String> step) {
		String[] arrStepStatus = new String[3];
		try {
			
			// Switch to new window opened
			for(String winHandle : webDriver.getWindowHandles()){
				webDriver.switchTo().window(winHandle);
			}
			arrStepStatus[0] = "Passed";
			arrStepStatus[1] = "Successful switch to new window";
			
		} catch (Exception e) {
			arrStepStatus[0] = "Failed";
			arrStepStatus[1] = e.getMessage();
		}

		return arrStepStatus;
	}
	/***********************************
	 * Static wait in seconds
	 * author: Francis Mangulabnan
	 * Date created: 2/25/2018
	 * Last update:
	 ************************************/
	public String[] waitFor(Map<String,String> step) {
		String[] arrStepStatus = new String[3];
		try {
			if (step.get("td_value") != null && step.get("td_value").length() > 0) {
				Thread.sleep((Integer.parseInt(step.get("td_value"))) * 1000);
				arrStepStatus[0] = "Passed";
				arrStepStatus[1] = "Waited for: " + step.get("td_value") + " seconds.";
			} else {
				arrStepStatus[0] = "Passed";
				arrStepStatus[1] = "Waited for: 0 second.(no parameter value found)";
			}
		} catch (Exception e) {
			arrStepStatus[0] = "Failed";
			arrStepStatus[1] = e.getMessage();
		}
		return arrStepStatus;
	}
	/***********************************
	 * Close current browser window
	 * author: Francis Mangulabnan
	 * Date created: 2/25/2018
	 * Last update:
	 ************************************/
	public String[] closeWindow(Map<String,String> step) {
		String[] arrStepStatus = new String[3];
		try {
			webDriver.close();
			arrStepStatus[0] = "Passed";
			arrStepStatus[1] = "window is now closed.";
		} catch (Exception e) {
			arrStepStatus[0] = "Failed";
			arrStepStatus[1] = e.getMessage();
		}

		return arrStepStatus;
	}

	/***********************************
	 * Close window handle browser window
	 * author: Francis Mangulabnan
	 * Date created: 2/25/2018
	 * Last update:
	 ************************************/
	public String[] closeWinHandle(Map<String,String> step) {
		String[] arrStepStatus = new String[3];
		try {
			if (step.get("td_value") != null && step.get("td_value").length() > 0) {
				webDriver.switchTo().window(step.get("td_value"));
				webDriver.close();
				log.info("Successful switch to window handle and closed : " + step.get("td_name_log"));
				arrStepStatus[0] = "Passed";
				arrStepStatus[1] = "Successful close window handle :" + step.get("td_name_log");
			} else {
				arrStepStatus[0] = "Failed";
				arrStepStatus[1] = "Window handle is required";
				log.info("Window handle is required");
			}

		} catch (Exception e) {
			arrStepStatus[0] = "Passed";
			arrStepStatus[1] = e.getMessage();
		}

		return arrStepStatus;
	}
	/***********************************
	 * window refresh
	 * author: Francis Mangulabnan
	 * Date created: 2/25/2018
	 * Last update:
	 ************************************/
	public String[] pageRefresh(Map<String,String> step) {
		String[] arrStepStatus = new String[3];
		try {
			webDriver.navigate().refresh();
			arrStepStatus[0] = "Passed";
			arrStepStatus[1] = "Web Page refreshed.";
			log.info("Web Page refreshed.");
		} catch (Exception e) {
			arrStepStatus[0] = "Failed";
			arrStepStatus[1] = e.getMessage();
		}
		return arrStepStatus;
	}
	/***********************************
	 * window page Back
	 * author: Francis Mangulabnan
	 * Date created: 2/25/2018
	 * Last update:
	 ************************************/
	public String[] pageBack(Map<String,String> step) {
		String[] arrStepStatus = new String[3];
		try {
			webDriver.navigate().back();
			arrStepStatus[0] = "Passed";
			arrStepStatus[1] = "Page is navigated back.";
			log.info("Page is navigated back.");
		} catch (Exception e) {
			arrStepStatus[0] = "Failed";
			arrStepStatus[1] = e.getMessage();
		}

		return arrStepStatus;
	}

	/***********************************
	 * window page Forward
	 * author: Francis Mangulabnan
	 * Date created: 2/25/2018
	 * Last update:
	 ************************************/
	public String[] pageForward(Map<String,String> step) {
		String[] arrStepStatus = new String[3];
		try {
			webDriver.navigate().forward();
			arrStepStatus[0] = "Passed";
			arrStepStatus[1] = "Page is navigated forward.";
			log.info("Page is navigated forward.");
		} catch (Exception e) {
			arrStepStatus[0] = "Failed";
			arrStepStatus[1] = e.getMessage();
		}
		return arrStepStatus;
	}

	/***********************************
	 * Accept alert
	 * author: Francis Mangulabnan
	 * Date created: 2/25/2018
	 * Last update:
	 ************************************/
	public String[] acceptAlert(Map<String,String> step) {
		String[] arrStepStatus = new String[3];
		try {
			webDriver.switchTo().alert().accept();
			arrStepStatus[0] = "Passed";
			arrStepStatus[1] = "Alert accepted.";
		} catch (Exception e) {
			arrStepStatus[0] = "Failed";
			arrStepStatus[1] = e.getMessage();
		}
		return arrStepStatus;
	}
	/***********************************
	 * Dismiss alert
	 * author: Francis Mangulabnan
	 * Date created: 2/25/2018
	 * Last update:
	 ************************************/
	public String[] dismissAlert(Map<String,String> step) {
		String[] arrStepStatus = new String[3];
		try {
			webDriver.switchTo().alert().dismiss();
			arrStepStatus[0] = "Passed";
			arrStepStatus[1] = "Alert dismissed.";
		} catch (Exception e) {
			arrStepStatus[0] = "Failed";
			arrStepStatus[1] = e.getMessage();
		}
		return arrStepStatus;
	}
	
	/***********************************
	 * select frame by using selector and string
	 * author: Francis Mangulabnan
	 * Date created: 2/25/2018
	 * Last update:
	 ************************************/
	public String[] selectFrame(Map<String,String> step) {
		String[] arrStepStatus = new String[3];
		try {
			WebElement element = locator.findElement(step);
			if(element == null) {
				arrStepStatus[0] = "Failed";
				arrStepStatus[1] = locator.elementError;
				return arrStepStatus;
			}
			webDriver.switchTo().frame(element);
			arrStepStatus[0] = "Passed";
			arrStepStatus[1] = "Frame is selected: " + step.get("el_string");
			log.info("Frame is selected: " + step.get("el_string"));
		} catch (Exception e) {
			arrStepStatus[0] = "Failed";
			arrStepStatus[1] = e.getMessage();
		}

		return arrStepStatus;
	}

	/***********************************
	 * unselect frame
	 * author: Francis Mangulabnan
	 * Date created: 2/25/2018
	 * Last update:
	 ************************************/
	public String[] unSelectFrame(Map<String,String> step) {
		String[] arrStepStatus = new String[3];
		try {
			webDriver.switchTo().defaultContent();
			arrStepStatus[0] = "Passed";
			arrStepStatus[1] = "Frame is unselected.";
			log.info("Frame is unselected.");
		} catch (Exception e) {
			arrStepStatus[0] = "Failed";
			arrStepStatus[1] = e.getMessage();
		}

		return arrStepStatus;
	}
	/***********************************
	 * select item from drop down by visible text
	 * author: Francis Mangulabnan
	 * Date created: 2/25/2018
	 * Last update:
	 ************************************/
	public String[] selectFromDropDown(Map<String,String> step) {
		String[] arrStepStatus = new String[3];
		try {
			WebElement element = locator.findElement(step);
			if(element == null) {
				arrStepStatus[0] = "Failed";
				arrStepStatus[1] = locator.elementError;
				return arrStepStatus;
			}
			Select selDD = new Select(element);
			selDD.selectByVisibleText(step.get("td_value"));
			WebElement option = selDD.getFirstSelectedOption();
			log.info("Selected: " + option.getText());
			arrStepStatus[0] = "Passed";
			arrStepStatus[1] = option.getText() + " is selected";

		} catch (Exception e) {
			log.info("Dropdown value not found. " + step.get("td_value_log"));
			arrStepStatus[0] = "Failed";
			arrStepStatus[1] = e.getMessage();
		}

		return arrStepStatus;
	}

	/***********************************
	 * select item from drop down by item index
	 * author: Francis Mangulabnan
	 * Date created: 2/25/2018
	 * Last update:
	 ************************************/
	public String[] selectDropDownIndex(Map<String,String> step) {
		String[] arrStepStatus = new String[3];
		try {
			WebElement element = locator.findElement(step);
			if(element == null) {
				arrStepStatus[0] = "Failed";
				arrStepStatus[1] = locator.elementError;
				return arrStepStatus;
			}
			if (step.get("td_value") != null && step.get("td_value").length() > 0) {
				Select selDD = new Select(element);
				selDD.selectByIndex(Integer.parseInt(step.get("td_value")));
				WebElement option = selDD.getFirstSelectedOption();
				log.info("Selected: " + option.getText());
				arrStepStatus[0] = "Passed";
				arrStepStatus[1] = option.getText() + " is selected";
			} else {
				arrStepStatus[0] = "Failed";
				arrStepStatus[1] = "Parameter is required.";
			}
		} catch (Exception e) {
			log.info("Error on parameter(must be integer)/Index not found");
			arrStepStatus[0] = "Failed";
			arrStepStatus[1] = e.getMessage();
		}

		return arrStepStatus;
	}
	/***********************************
	 * validate text from the drop down list
	 * author: Francis Mangulabnan
	 * Date created: 2/25/2018
	 * Last update:
	 ************************************/
	public String[] validateDropDownText(Map<String,String> step) {
		String[] arrStepStatus = new String[3];
		try {
			WebElement element = locator.findElement(step);
			if(element == null) {
				arrStepStatus[0] = "Failed";
				arrStepStatus[1] = locator.elementError;
				return arrStepStatus;
			}
			String strDDText = new Select(element).getFirstSelectedOption().getText();

			if (strDDText.contentEquals(step.get("td_value"))) {
				arrStepStatus[0] = "Passed";
				arrStepStatus[1] = "Actual: " + strDDText + " = Expected: " + step.get("td_value_log");
				log.info("Actual: " + strDDText + " = Expected: " + step.get("td_value_log"));
			} else {
				arrStepStatus[0] = "Failed";
				arrStepStatus[1] = "[Not Equal] Actual: " + strDDText + " <> Expected: " + step.get("td_value_log");
				log.info("[Not Equal] Actual: " + strDDText + " <> Expected: " + step.get("td_value_log"));
			}

		} catch (Exception e) {
			arrStepStatus[0] = "Failed";
			arrStepStatus[1] = e.getMessage();
		}

		return arrStepStatus;
	}

	/***********************************
	 * Get dropdown text value
	 * author: Francis Mangulabnan
	 * Date created: 2/25/2018
	 * Last update:
	 ************************************/
	public String[] getDropDownToVar(Map<String,String> step) {
		String[] arrStepStatus = new String[3];
		try {
			WebElement element = locator.findElement(step);
			if(element == null) {
				arrStepStatus[0] = "Failed";
				arrStepStatus[1] = locator.elementError;
				return arrStepStatus;
			}
			String strDDText = new Select(element).getFirstSelectedOption().getText();

			strDDText = strDDText.replaceAll("\\r\\n|\\r|\\n", " ");
			strDDText = strDDText.trim();
			log.info("Get Element text:  " + strDDText);
			if (step.get("td_name") != null && step.get("td_name").length() > 0) {
				if (step.get("td_value") != null && step.get("td_value").length() > 0) {
					Pattern pattern = Pattern.compile(step.get("td_value"));
					Matcher matcher = pattern.matcher(strDDText);
					if (matcher.find()) {
						log.info("RegEx Matched:  " + matcher.group(1));
						testData.put(step.get("td_name"), matcher.group(1));
					} else {
						log.info("RegEx Not Found.");
						testData.put(step.get("td_name"), "");
					}

				} else {
					testData.put(step.get("td_name"), strDDText);
				}

				arrStepStatus[0] = "Passed";
				arrStepStatus[1] = "Element text stored to variable " + step.get("td_name") + ":" + testData.get(step.get("td_name"));
			} else {
				arrStepStatus[0] = "Failed";
				arrStepStatus[1] = "Parameter name is required";
			}

		} catch (Exception e) {
			arrStepStatus[0] = "Failed";
			arrStepStatus[1] = e.getMessage();
		}

		return arrStepStatus;
	}

	/***********************************
	 * Check element ispresent
	 * author: Francis Mangulabnan
	 * Date created: 2/25/2018
	 * Last update:
	 ************************************/
	public String[] elementIsPresent(Map<String,String> step) {
		String[] arrStepStatus = new String[3];
		try {
			if (locator.findElement(step) != null) {
				arrStepStatus[0] = "Passed";
				arrStepStatus[1] = "Element is existing.";
				log.info("Element is existing.");
			} else {
				arrStepStatus[0] = "Failed";
				arrStepStatus[1] = "Element does not exist.";
				log.info("Element does not exist.");
			}

		} catch (Exception e) {
			arrStepStatus[0] = "Failed";
			arrStepStatus[1] = e.getMessage();
		}

		return arrStepStatus;
	}

	/***********************************
	 * Check element is not present
	 * author: Francis Mangulabnan
	 * Date created: 2/25/2018
	 * Last update:
	 ************************************/
	public String[] elementIsNotPresent(Map<String,String> step) {
		String[] arrStepStatus = new String[3];
		try {
			if (locator.findElement(step) == null) {
				arrStepStatus[0] = "Passed";
				arrStepStatus[1] = "Element does not exist.";
				log.info("Element does not exist.");
			} else {
				arrStepStatus[0] = "Failed";
				arrStepStatus[1] = "Element is existing.";
				log.info("Element is existing.");
			}

		} catch (Exception e) {
			arrStepStatus[0] = "Failed";
			arrStepStatus[1] = e.getMessage();
		}

		return arrStepStatus;
	}

	/***********************************
	 * Check box is checked
	 * author: Francis Mangulabnan
	 * Date created: 2/25/2018
	 * Last update:
	 ************************************/
	public String[] isChecked(Map<String,String> step) {
		String[] arrStepStatus = new String[3];
		try {
			WebElement element = locator.findElement(step);
			if(element == null) {
				arrStepStatus[0] = "Failed";
				arrStepStatus[1] = locator.elementError;
				return arrStepStatus;
			}
			if (element.isSelected()) {
				arrStepStatus[0] = "Passed";
				arrStepStatus[1] = "Web Element is selected.";
				log.info("Web Element is selected.");
			} else {
				arrStepStatus[0] = "Failed";
				arrStepStatus[1] = "Web Element is not selected.";
				log.info("Web Element is not selected.");
			}

		} catch (Exception e) {
			arrStepStatus[0] = "Failed";
			arrStepStatus[1] = e.getMessage();
		}

		return arrStepStatus;
	}

	/***********************************
	 * Check box is not checked
	 * author: Francis Mangulabnan
	 * Date created: 2/25/2018
	 * Last update:
	 ************************************/
	public String[] isUnchecked(Map<String,String> step) {
		String[] arrStepStatus = new String[3];
		try {
			WebElement element = locator.findElement(step);
			if(element == null) {
				arrStepStatus[0] = "Failed";
				arrStepStatus[1] = locator.elementError;
				return arrStepStatus;
			}
			if (element.isSelected()) {
				arrStepStatus[0] = "Failed";
				arrStepStatus[1] = "Web Element is not selected.";
				log.info("Web Element is not selected.");
			} else {
				arrStepStatus[0] = "Passed";
				arrStepStatus[1] = "Web Element is selected.";
				log.info("Web Element is selected.");
			}

		} catch (Exception e) {
			arrStepStatus[0] = "Failed";
			arrStepStatus[1] = e.getMessage();
		}

		return arrStepStatus;
	}
	/***********************************
	 * Check check box
	 * author: Francis Mangulabnan
	 * Date created: 2/25/2018
	 * Last update:
	 ************************************/
	public String[] check(Map<String,String> step) {
		String[] arrStepStatus = new String[3];
		try {
			WebElement element = locator.findElement(step);
			if(element == null) {
				arrStepStatus[0] = "Failed";
				arrStepStatus[1] = locator.elementError;
				return arrStepStatus;
			}
			if (element.isSelected()) {
				arrStepStatus[0] = "Passed";
				arrStepStatus[1] = "Web Element is already checked.";
				log.info("Web Element is already checked.");
			} else {
				arrStepStatus[0] = "Passed";
				element.click();
				arrStepStatus[1] = "Web Element is checked.";
				log.info("Web Element is checked.");
			}

		} catch (Exception e) {
			arrStepStatus[0] = "Failed";
			arrStepStatus[1] = e.getMessage();
		}

		return arrStepStatus;
	}
	/***********************************
	 * Uncheck check box
	 * author: Francis Mangulabnan
	 * Date created: 2/25/2018
	 * Last update:
	 ************************************/
	public String[] unCheck(Map<String,String> step) {
		String[] arrStepStatus = new String[3];
		try {
			WebElement element = locator.findElement(step);
			if(element == null) {
				arrStepStatus[0] = "Failed";
				arrStepStatus[1] = locator.elementError;
				return arrStepStatus;
			}
			if (element.isSelected()) {
				element.click();
				arrStepStatus[0] = "Passed";
				arrStepStatus[1] = "Web Element is unchecked.";
				log.info("Web Element is already checked.");
			} else {
				arrStepStatus[0] = "Passed";
				arrStepStatus[1] = "Web Element is already unchecked.";
				log.info("Web Element is already unchecked.");
			}

		} catch (Exception e) {
			arrStepStatus[0] = "Failed";
			arrStepStatus[1] = e.getMessage();
		}

		return arrStepStatus;
	}
	/***********************************
	 * check if web element is displayed
	 * author: Francis Mangulabnan
	 * Date created: 2/25/2018
	 * Last update:
	 ************************************/
	public String[] isDisplayed(Map<String,String> step) {
		String[] arrStepStatus = new String[3];
		try {
			WebElement element = locator.findElement(step);
			if(element == null) {
				arrStepStatus[0] = "Failed";
				arrStepStatus[1] = locator.elementError;
				return arrStepStatus;
			}
			if (element.isDisplayed()) {
				arrStepStatus[0] = "Passed";
				arrStepStatus[1] = "Web Element is displayed.";
				log.info("Web Element is displayed.");
			} else {
				arrStepStatus[0] = "Failed";
				arrStepStatus[1] = "Web Element is not displayed.";
				log.info("Web Element is not displayed.");
			}
		} catch (Exception e) {
			arrStepStatus[0] = "Failed";
			arrStepStatus[1] = e.getMessage();
		}

		return arrStepStatus;
	}
	/***********************************
	 * check if web element is not displayed
	 * author: Francis Mangulabnan
	 * Date created: 2/25/2018
	 * Last update:
	 ************************************/
	public String[] isNotDisplayed(Map<String,String> step) {
		String[] arrStepStatus = new String[3];
		try {
			WebElement element = locator.findElement(step);
			if(element == null) {
				arrStepStatus[0] = "Failed";
				arrStepStatus[1] = locator.elementError;
				return arrStepStatus;
			}
			if (element.isDisplayed()) {
				arrStepStatus[0] = "Failed";
				arrStepStatus[1] = "Web Element is displayed.";
				log.info("Web Element is displayed.");
			} else {
				arrStepStatus[0] = "Passed";
				arrStepStatus[1] = "Web Element is not displayed.";
				log.info("Web Element is not displayed.");
			}
		} catch (Exception e) {
			arrStepStatus[0] = "Failed";
			arrStepStatus[1] = e.getMessage();
		}

		return arrStepStatus;
	}

	/***********************************
	 * Scroll to bottom page
	 * author: Francis Mangulabnan
	 * Date created: 8/11/2018
	 * Last update:
	 ************************************/
	public String[] scrollToBottom(Map<String, String> step) {
		String[] arrStepStatus = new String[3];
		try {
			
			((JavascriptExecutor)webDriver).executeScript("window.scrollTo(0, document.scrollingElement.scrollHeight)");
			arrStepStatus[0] = "Passed";
			arrStepStatus[1] = "Scrolled to bottom";
			log.info("Scrolled to bottom");
		} catch (Exception e) {
			arrStepStatus[0] = "Failed";
			arrStepStatus[1] = e.getMessage();
		}
		return arrStepStatus;
	}
	/***********************************
	 * wait until element is invisible
	 * author: Francis Mangulabnan
	 * Date created: 8/11/2018
	 * Last update:
	 ************************************/
	public String[] waitUntilElementInvisible(Map<String, String> step) {
		String[] arrStepStatus = new String[3];
		try {
			if(locator.waitUntilElementIsNotDisplayed(step)) {
				arrStepStatus[0] = "Passed";
				arrStepStatus[1] = "Element is invisible";
				log.info("Element is invisible");
			} else {
				arrStepStatus[0] = "Failed";
				arrStepStatus[1] = "Element is still visible";
			}
		} catch (Exception e) {
			arrStepStatus[0] = "Failed";
			arrStepStatus[1] = e.getMessage();
		}
		return arrStepStatus;
	}
	/***********************************
	 * select Lightning Select Object select value from dropdown
	 * author: Francis Mangulabnan
	 * Date created: 8/5/2018
	 * Last update:
	 ************************************/
	public String[] lightningSelectFromDropDown(Map<String,String> step) {
		String[] arrStepStatus = new String[3];
		try {
			WebElement element = locator.findElement(step);
			if(element == null) {
				arrStepStatus[0] = "Failed";
				arrStepStatus[1] = locator.elementError;
				return arrStepStatus;
			}
			element.sendKeys(Keys.SPACE);
			Thread.sleep(3000);
			step.put("el_string","//div[contains(@class, 'visible')][contains(@class, 'popupTargetContainer')]//ul/li/a");
			List<WebElement> elements = locator.findElements(step);
			
			for (WebElement el : elements) {
				String elementText  = el.getText().trim();
				if (elementText.contentEquals(step.get("td_value"))) {
					el.click();
					log.info("Selected: " + elementText);
					arrStepStatus[0] = "Passed";
					arrStepStatus[1] = elementText + " is selected";
					return arrStepStatus;
				}
			}
			arrStepStatus[0] = "Failed";
			arrStepStatus[1] = "Text Value not Found";

		} catch (Exception e) {
			log.info("Error seleting value from dropdown. " + step.get("td_value_log"));
			arrStepStatus[0] = "Failed";
			arrStepStatus[1] = e.getMessage();
		}

		return arrStepStatus;
	}
	/***********************************
	 * select Lightning Set Lookup value
	 * author: Francis Mangulabnan
	 * Date created: 9/13/2018
	 * Last update:
	 ************************************/
	public String[] lightningSetLookup(Map<String,String> step) {
		String[] arrStepStatus = new String[3];
		try {
			WebElement element = locator.findElement(step);
			if(element == null) {
				arrStepStatus[0] = "Failed";
				arrStepStatus[1] = locator.elementError;
				return arrStepStatus;
			}
			element.click();
		    element.sendKeys(Keys.chord(Keys.CONTROL, "a"));
		    element.sendKeys(Keys.BACK_SPACE);
		    element.sendKeys(step.get("td_value"));
			
			//element.sendKeys(Keys.SPACE);
			Thread.sleep(3000);
			
			step.put("el_string",".//following::div[1]//div[@class='listContent']//div[@title='" + step.get("td_value") + "']");
			List<WebElement> elements = locator.findElements(step);
			
			for (WebElement el : elements) {
				String elementText  = el.getText().trim();
				if (elementText.contentEquals(step.get("td_value"))) {
					el.click();
					log.info("Lookup Selected: " + elementText);
					arrStepStatus[0] = "Passed";
					arrStepStatus[1] = elementText + " is selected";
					return arrStepStatus;
				}
			}
			arrStepStatus[0] = "Failed";
			arrStepStatus[1] = "Lookup Text Value not Found";

		} catch (Exception e) {
			log.info("Error seleting value from Lookup. " + step.get("td_value_log"));
			arrStepStatus[0] = "Failed";
			arrStepStatus[1] = e.getMessage();
		}

		return arrStepStatus;
	}
}
