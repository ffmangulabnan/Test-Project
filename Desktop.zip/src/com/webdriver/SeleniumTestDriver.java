package com.webdriver;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import com.utilities.EmailSender;
import com.utilities.MultipartUtility;
import com.utilities.MySqlDB;
import com.utilities.ServerLog;

/***********************************
 * Main Driver of selenium
 * author: Francis Mangulabnan
 * Date created: 2/22/2018
 * Last update:
 ************************************/
public class SeleniumTestDriver {
	private ProjectDB pDB = null;
	private Logger log = null;
	private Logger serverLog = null;
	private String appPath = new File("").getAbsolutePath();
	private static MySqlDB sqlDB;
	
	public SeleniumTestDriver(String dbName,String runId,Logger sLog,MySqlDB msql,String sched) {
		sqlDB = msql;
		pDB = new ProjectDB(dbName);
		serverLog = sLog;
		List<Map<String, String>> testRun = pDB.getTestRun(runId);

		if(testRun.size() > 0) {
			if(sched.equalsIgnoreCase("yes")) {
				//log.info("Schedued Run, resetting TestSuite status before execution.");
				pDB.resetTestRunStatus(runId);
			}
			
			String testRunName = testRun.get(0).get("name");
			String logName = testRunName + "-" + getDateTime("MMddyyyyHHmmss");
			String fileDir = appPath + "/Result/" + dbName+"/"+logName;
			String logFileName = fileDir + "/" + logName + ".log";
			long  histId = pDB.addTestRunHistory(runId);
			String browser = testRun.get(0).get("browser");
			String machine = testRun.get(0).get("machine");
			log = new ServerLog(logFileName).getLogger(); 
			log.info("Test Run Started.");
			log.info("Name: " + testRunName);
			log.info("Description: " + testRun.get(0).get("description"));
			log.info("Browser: " + browser);
			log.info("Machine: " + machine);
			log.info("Date: " + new Date());
			log.info("---------------------------------------------------------------------------------------------------");
			WebDriver webDriver = createBrowserSession(browser);
			try {
				if(webDriver!=null) {
					executeTestRun(runId,webDriver,dbName,logName,histId,browser, machine,sched);
					webDriver.quit();
					log.info("Web driver is now closed.");
				} else {
					log.info("Unable to created browser session.");
				}
			}catch(Exception e) {
				webDriver.quit();
				log.error("Exception Encountere. Web Driver quit");
			}
			
			try {
				String logFileNamePDF = fileDir + "/" + logName + ".pdf";
				TextToPDF textToPdf = new TextToPDF(log);
				textToPdf.convertTextToPDF(logFileName,logFileNamePDF);
				if(waitForFileExist(logFileNamePDF)) {
					log.info("Uploading Result log...");
					uploadResult(logFileNamePDF,dbName+"/"+logName);
					log.info("Uploading Result log [Done]");
				}
				String summaryFileNamePDF = fileDir + "/" + logName + "summary.pdf";
				List<Map<String, String>> runResult = pDB.getTestRun(runId);
				List<Map<String, String>> runTestResult = pDB.getTestRunTestcases(runId);
				textToPdf.createSummaryPDF(summaryFileNamePDF,runTestResult,runResult);
				if(waitForFileExist(summaryFileNamePDF)) {
					log.info("Uploading Result Summary...");
					uploadResult(summaryFileNamePDF,dbName+"/"+logName);
					log.info("Uploading Result Summary [Done]");
					pDB.updateTestRunHistory(histId,"/Result/" + dbName+"/"+logName+ "/" + logName + ".pdf","/Result/" + dbName+"/"+logName+ "/" + logName + "summary.pdf");
				}
				
				if(runResult.get(0).get("email_on").equalsIgnoreCase("yes")){
					log.info("Sending email report...");
					EmailSender email = new EmailSender();
					String response = email.sendEmail(sqlDB,summaryFileNamePDF,runResult,runTestResult);
					log.info("Email report " + response);
				}
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			log.info("Execution Finished!");
		}
	}
	/***********************************
	 * Execution per testcase
	 * author: Francis Mangulabnan
	 * Date created: 2/22/2018
	 * Last update:
	 ************************************/
	public void executeTestRun(String runId,WebDriver webDriver,String dbName,String logName,long histId,String browser, String machine, String sched) {
		String fileDir = appPath + "/Result/" + dbName+"/"+logName;
		try {
			log.info("Retrieving Testcase data...");
			List<Map<String, String>> testcase = pDB.getTestRunTestcases(runId);
			pDB.updateTestRunStartTime(runId);
			ActionDriver aDriver= new ActionDriver(log,webDriver);
			for (Map<String, String> tc : testcase) {
				log.info("---------------------------------------------------------------------------------------------------");
				log.info("Testcase Name: " + tc.get("name"));
				List<Map<String, String>> testResult = new ArrayList<Map<String, String>>();
				String runTcId = tc.get("id");
				pDB.updateTestcaseRunStartTime(runTcId);
				log.info("Retrieving Test steps data...");
				List<Map<String, String>> steps = pDB.getTestRunTestcaseSteps(runTcId);
				String[] stepResult = new String[3];
				for (Map<String, String> step : steps) {
					stepResult[0] = "";
					stepResult[1] = "";
					stepResult[2] = "";
					log.info("-----------------------------------------------");
					log.info("Step Name : " + step.get("name"));
					log.info("Step Description : " + step.get("description"));
					log.info("Element : " + step.get("el_selector") + ":" + step.get("el_string"));
					log.info("Element find: " + step.get("el_find_method"));
					log.info("Element find timeout: " + step.get("el_timeout"));
					log.info("Action : " + step.get("action"));
					log.info("Param Name: " + step.get("td_name"));
					log.info("Param Value: " + step.get("td_value"));
					log.info("Screenshot : " + step.get("capture"));
					stepResult = aDriver.executeAction(step,tc,fileDir);
					pDB.updateRunStepsResult(step.get("id"),stepResult[0],stepResult[1]);
					log.info("Step Result : " + stepResult[0]);
					log.info("Remarks : " +  stepResult[1]);
					if(step.get("capture").contentEquals("Y")){
						step.put("status", stepResult[0]);
						step.put("remarks", stepResult[1]);
						step.put("screenshot", stepResult[2]);
						testResult.add(step);
					} else if(stepResult[0].equalsIgnoreCase("Failed")){
						step.put("status", stepResult[0]);
						step.put("remarks", stepResult[1]);
						step.put("screenshot", stepResult[2]);
						testResult.add(step);
					}
					if (stepResult[0].equalsIgnoreCase("Failed")) {
						break;
					}
				}	
				//generate pdf screenshots
				//testResult
				Screenshot screenCapture = new Screenshot(log,webDriver);
				String testCase = tc.get("sort") +"-"+ tc.get("name");
				String strSSPDFName = fileDir + "/" + testCase  + "/" + testCase + ".pdf";
				log.info("Creating PDF file for screenshots...");
				screenCapture.createPdfDocument(strSSPDFName,testResult,tc.get("name"),browser,machine);
				pDB.updateTestcaseRunEndTime(runTcId,pDB.getTestRunTestcasesStatus(runTcId));
				if(waitForFileExist(strSSPDFName)) {
					log.info("Uploading Result Screenshot...");
					uploadResult(strSSPDFName,dbName+"/"+logName+ "/" + testCase);
					log.info("Uploading Result Screenshot [Done]");
					pDB.addTestcaseHistory(runTcId,"/Result/" + dbName+"/"+logName+ "/" + testCase  + "/" + testCase + ".pdf",histId,runId);
				}
				
			}
			pDB.updateTestRunEndTime(runId,pDB.getTestRunStatus(runId),sched);

		}catch(Exception e) {
			pDB.updateTestRunEndTime(runId,"Failed",sched);
			pDB.updateTestRunHistory(histId,"","");
			log.info("Test Suite Failed : Exception encountered: " + e.getMessage());
			e.printStackTrace();
		}
	}
	/***********************************
	 * Create browser session based on parameter browser
	 * author: Francis Mangulabnan
	 * Date created: 2/22/2018
	 * Last update:
	 ************************************/
	private WebDriver createBrowserSession(String browser) {	
		log.info("Creating browser session...");
		WebDriver webDriver = null;
		if (browser.equalsIgnoreCase("firefox")) {
			webDriver = new GeckoTestDriver().getWebDriver();
		} else if (browser.equalsIgnoreCase("chrome")) {
			webDriver = new ChromeTestDriver().getWebDriver();
		} else if (browser.equalsIgnoreCase("internet explorer")) {
			webDriver = new IETestDriver().getWebDriver();
		} else {
			log.info("Browser not supported: " + browser);
		}
		log.info("Browser session created: " + webDriver.getWindowHandles());
		return webDriver;
	}
	/***********************************
	 * Get datetime using format parameter
	 * author: Francis Mangulabnan
	 * Date created: 2/22/2018
	 * Last update:
	 ************************************/
	public String getDateTime(String format) {
		SimpleDateFormat df = new SimpleDateFormat(format);
		return df.format(new Date());
	}
	/***********************************
	 * Upload Result file to server
	 * author: Francis Mangulabnan
	 * Date created: 5/11/2018
	 * Last update:
	 ************************************/
	public void uploadResult(String file,String folder) {
		MySqlDB mysql = new MySqlDB();
		String charset = "UTF-8";
		File uploadFile = new File(file);
		String requestURL = mysql.getConfigValue("resultUploadApi");
		try {
			serverLog.info("Uploading Result..." + file);
			log.info("Uploading Result..." + file);
			MultipartUtility multipart = new MultipartUtility(requestURL, charset);
            
			multipart.addHeaderField("User-Agent", "CodeJava");
			multipart.addHeaderField("Test-Header", "Header-Value");
			multipart.addFormField("folder", folder);
			multipart.addFormField("key", mysql.getResultKey());
			multipart.addFilePart("fileUpload", uploadFile);

			List<String> response = multipart.finish();
            
			// System.out.println("SERVER REPLIED:");
            
			for (String line : response) {
				log.info("Uploading Result: " + line);
				serverLog.info("Uploading Result: " + line);
				// System.out.println(line);
			}
		} catch (IOException ex) {
           //System.err.println(ex);
		}
	}
	private boolean waitForFileExist(String file) {
		File uploadFile = new File(file);
		log.info("Waiting for file to exist.");
		for (int i = 0; i < 30; i++) {
			try {
				if(uploadFile.exists() && !uploadFile.isDirectory()) { 
					log.info("File found.");
					return true;
				}
				Thread.sleep(1000);
			} catch (Exception e) {
				log.info("Result File Checking Exception: " + e.getMessage().toString());
				return false;
			}
		}
		log.info("File Not found.");
		return false;
	}
}
