package com.webdriver;

import java.io.File;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;

import com.utilities.ConfigDB;
/***********************************
 * Create Firefox driver
 * author: Francis Mangulabnan
 * Date created: 2/21/2018
 * Last update:
 ************************************/
public class GeckoTestDriver {
	public WebDriver webDriver = null;
	private String appPath = new File("").getAbsolutePath();
	private ConfigDB dbConfig = new ConfigDB();
	public GeckoTestDriver(){
		try {
			System.setProperty("webdriver.gecko.driver", appPath + "\\selenium\\driver\\geckodriver.exe");
			FirefoxProfile profile = new FirefoxProfile();
			FirefoxOptions firefoxOptions = new FirefoxOptions().setProfile(profile);
		    firefoxOptions.setCapability("marionette", true);
		    firefoxOptions.setCapability("acceptInsecureCerts", true);
		    if(dbConfig.getConfigValue("headless").contentEquals("true")){
		    	firefoxOptions.addArguments("--headless");
		    	firefoxOptions.addArguments("start-maximized");
			}
		    webDriver = new FirefoxDriver(firefoxOptions);
		    //webDriver.manage().window().maximize();
		}catch(Exception e){
			quitWebDriver();
			webDriver = null;
			e.printStackTrace();
		}
	}
	
	public WebDriver getWebDriver(){
		return this.webDriver;
	}
	private void quitWebDriver(){
		try{
			webDriver.quit();
		}catch(Exception e){
			
		}
	}
}
