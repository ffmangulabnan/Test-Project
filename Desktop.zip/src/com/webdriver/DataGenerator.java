package com.webdriver;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;

public class DataGenerator {
	public DataGenerator() { }
	public String generateString(String format) {
		String number = "123456789";
		String characters = "abcdefghijklmnopqrstuvwxyz";
		String allCaps = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	    Random rnd = new Random();
	    char[] text = new char[format.length()];
		for(int i = 0; i < format.length(); i++){
			char c = format.charAt(i);
			text[i] = c;
			if(String.valueOf(c).contentEquals("#")) {
				text[i] = number.charAt(rnd.nextInt(number.length()));
			} else if(String.valueOf(c).contentEquals("*")) {
				text[i] = characters.charAt(rnd.nextInt(characters.length()));
			} else if(String.valueOf(c).contentEquals("^")) {
				text[i] = allCaps.charAt(rnd.nextInt(allCaps.length()));
			}
		}
		return new String(text);
	}
	public String generateDate(String format) {
		String[] df = format.split("\\|",2);
		int length = Integer.parseInt(df[0]);
		DateFormat dtf = new SimpleDateFormat(df[1]);
		Date currentDate = new Date();

		Calendar c = Calendar.getInstance();
		c.setTime(currentDate);
		c.add(Calendar.DATE, length);

		Date date = c.getTime();
		return dtf.format(date);
	}
}
