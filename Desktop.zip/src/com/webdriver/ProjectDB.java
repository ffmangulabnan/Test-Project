package com.webdriver;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.JOptionPane;

import com.utilities.ConfigDB;
/***********************************
 * mySql Database Connection for projects table
 * author: Francis Mangulabnan
 * Date created: 2/20/2018
 * Last update:
 ************************************/
public class ProjectDB {
	private static ConfigDB dbConfig = new ConfigDB();

	private AesCipher aesCipher = new AesCipher();
	public Connection conn = null;
	public String mySqlDBHostname = dbConfig.getConfigValue("host");
	private String mySqlDBPort = dbConfig.getConfigValue("port");
	public String mySqlUser = dbConfig.getConfigValue("user");
	public String mySqlPass =  aesCipher.decrypt(dbConfig.getConfigValue("password")).toString();
	//private Statement statement = null;
    private static ResultSet resultSet = null;
   // private PreparedStatement 	statement = null;
	public ProjectDB(String dbName) {
		dataBaseConnect(dbName);
	}
	/***********************************
	 * mySql connection
	 * author: Francis Mangulabnan
	 * Date created: 2/21/2018
	 * Last update:
	 ************************************/
	public void dataBaseConnect(String dbName){
		try {
			Class.forName("com.mysql.jdbc.Driver");
			mySqlDBHostname = dbConfig.getConfigValue("host");
			mySqlUser = dbConfig.getConfigValue("user");
			mySqlPass =  aesCipher.decrypt(dbConfig.getConfigValue("password")).toString();
			conn = DriverManager.getConnection("jdbc:mysql://"+mySqlDBHostname+":"+mySqlDBPort+"/"+dbName,mySqlUser,mySqlPass);
		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Error connecting to database!" + e.getMessage(), "Error",JOptionPane.ERROR_MESSAGE);
			System.exit(0);
		}
	}
	/***********************************
	 * mySql Get test run name status
	 * author: Francis Mangulabnan
	 * Date created: 2/21/2018
	 * Last update:
	 ************************************/
	public String getTestRunName(String id){
		try {
			//statement = conn.createStatement();
			//resultSet = statement.executeQuery("select name from tr_tbl where id='"+id+"';");
			PreparedStatement 	statement = null;
			String query = "select name from tr_tbl where id='"+id+"';";
			statement = conn.prepareStatement(query);
			resultSet = statement.executeQuery(query);
			if(resultSet.next()){
				String user = resultSet.getString("name");
				statement.close();
				return user;
			}
			statement.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	/***********************************
	 * mySql Get test run details
	 * author: Francis Mangulabnan
	 * Date created: 2/22/2018
	 * Last update:
	 ************************************/
	public List<Map<String, String>> getTestRun(String id) {
		return executeSelectQuery("select * from tr_tbl where id='"+id+"';");
	}
	/***********************************
	 * mySql Get testcases
	 * author: Francis Mangulabnan
	 * Date created: 2/22/2018
	 * Last update:
	 ************************************/
	public List<Map<String, String>> getTestRunTestcases(String trId) {
		return executeSelectQuery("select * from tr_tc_tbl where tr_id='"+trId+"' order by sort asc;");
	}
	/***********************************
	 * set testrun testcase status based on step status
	 * author: Francis Mangulabnan
	 * Date created: 2/25/2018
	 * Last update:
	 ************************************/
	public String getTestRunTestcasesStatus(String tcId) {
		List<Map<String, String>> failedTC = executeSelectQuery("select * from tr_tc_s_tbl where tr_tc_id='"+tcId+"' and status='Failed';");
		if(failedTC.size()>0){
			return "Failed";
		}
		return "Passed";
	}
	/***********************************
	 * set testrun status based on testcase status
	 * author: Francis Mangulabnan
	 * Date created: 2/22/2018
	 * Last update:
	 ************************************/
	public String getTestRunStatus(String trId) {
		List<Map<String, String>> failedTC = executeSelectQuery("select * from tr_tc_tbl where tr_id='"+trId+"' and status='Failed';");
		if(failedTC.size()>0){
			return "Failed";
		}
		return "Passed";
	}
	/***********************************
	 * mySql Get testrun steps
	 * author: Francis Mangulabnan
	 * Date created: 2/22/2018
	 * Last update:
	 ************************************/
	public List<Map<String, String>> getTestRunTestcaseSteps(String tcId) {
		return executeSelectQuery("select * from tr_tc_s_tbl where tr_tc_id='"+tcId+"' order by sort asc;");
	}
	/***********************************
	 * Update TestSuite status to No Run
	 * author: Francis Mangulabnan
	 * Date created: 2/22/2018
	 * Last update:
	 ************************************/
	public void resetTestRunStatus(String trId) {
		executeUpdateQuery("update tr_tbl set status='Ongoing',start=NULL,end=NULL,duration=NULL where id ='" + trId + "';");
				executeUpdateQuery("update tr_tc_tbl set start=NULL,end=NULL,duration=NULL,status='No Run' where tr_id='" + trId + "';");
						executeUpdateQuery("update tr_tc_s_tbl set status='No Run',remarks='' where tr_tc_id in (select id from tr_tc_tbl where tr_id = '" + trId + "');");
	}
	/***********************************
	 * Update tr_tbl start and status of testcase
	 * author: Francis Mangulabnan
	 * Date created: 2/22/2018
	 * Last update:
	 ************************************/
	public void updateTestRunStartTime(String trId) {
		executeUpdateQuery("update tr_tbl set start=sysdate(), status='Ongoing' where id ='"+trId+"';");
	}
	/***********************************
	 * Update tr_tbl end column
	 * author: Francis Mangulabnan
	 * Date created: 2/22/2018
	 * Last update:
	 ************************************/
	public void updateTestcaseRunEndTime(String trId,String status) {
		executeUpdateQuery("update tr_tc_tbl set end=sysdate() , status='"+status+"',duration=sec_to_time((select timestampdiff(SECOND,start,sysdate())))"
				+ " where id ='"+trId+"';");
	}

	/***********************************
	 * Update tr_tc_tbl start and status of testcase
	 * author: Francis Mangulabnan
	 * Date created: 2/22/2018
	 * Last update:
	 ************************************/
	public void updateTestcaseRunStartTime(String trId) {
		executeUpdateQuery("update tr_tc_tbl set start=sysdate(), status='Ongoing' where id ='"+trId+"';");
	}
	/***********************************
	 * Update tr_tc_tbl end column
	 * author: Francis Mangulabnan
	 * Date created: 2/22/2018
	 * Last update:
	 ************************************/
	public void updateTestRunEndTime(String trId,String status,String lock) {
		executeUpdateQuery("update tr_tbl set end=sysdate(),status='"+status+"',locked='"+lock+"',duration=sec_to_time((select timestampdiff(SECOND,start,sysdate())))"
				+ "where id ='"+trId+"';");
	}

	/***********************************
	 * Update tr_tc_s_tbl status column
	 * author: Francis Mangulabnan
	 * Date created: 2/22/2018
	 * Last update:
	 ************************************/
	public void updateRunStepsResult(String id, String value, String remarks) {
		
		value = ((value == null) ? "" : value).replaceAll("'", "''");
		remarks = ((remarks == null) ? "" : remarks).replaceAll("'", "''");
		executeUpdateQuery("update tr_tc_s_tbl set status='"+value+"', remarks='"+remarks+"' where id='"+id+"';");

	}
	/***********************************
	 * Insert test run history
	 * author: Francis Mangulabnan
	 * Date created: 5/8/2018
	 * Last update:
	 ************************************/
	public long addTestRunHistory(String id) {
		return executeInsertQuery("insert into tr_history_tbl "
									+ "(tr_id,machine,browser,start,end,duration,status,logs,summary,created_by,created_date) " + 
				"select id,machine,browser,start,end,duration,status,'' as logs,'' as summary,"
						+ "updated_by as created_by,sysdate() as created_date "
				+ "from tr_tbl where id = '"+id+"';");

	}
	/***********************************
	 * update test run history
	 * author: Francis Mangulabnan
	 * Date created: 5/9/2018
	 * Last update:
	 ************************************/
	public void updateTestRunHistory(long id,String logs,String summary) {
		executeUpdateQuery("update tr_history_tbl tr_hist,tr_tbl tr" + 
				" set" + 
				" tr_hist.status = tr.status," + 
				" tr_hist.start = tr.start," + 
				" tr_hist.end = tr.end," + 
				" tr_hist.duration= tr.duration," + 
				" tr_hist.logs= '"+logs+"'," + 
				" tr_hist.summary= '"+summary+"'" + 
				" where" + 
				" tr_hist.tr_id = tr.id" + 
				" and tr_hist.id = '"+id+"';");

	}
	/***********************************
	 * Insert testcase history
	 * author: Francis Mangulabnan
	 * Date created: 5/8/2018
	 * Last update:
	 ************************************/
	public void addTestcaseHistory(String id,String filePath,long histId,String rid) {
		
		executeInsertQuery("insert into tr_tc_history_tbl "
									+ "(tr_id,tr_tc_id,tr_history_id,start,end,duration,status,screenshot,created_date) "
									+"select \""+rid+"\" as tr_id,"
									+ "\""+id+"\" as tr_history_id,"
									+ "\""+histId+"\" as tr_history_id,"
									+ "start,end,duration,status,\""+filePath+"\" as screeshot,"
									+ "sysdate() as created_date "
									+ "from tr_tc_tbl where id = '"+id+"';");
		
	}

	/***********************************
	 * Execute Select Mysql query and convert result to list
	 * author: Francis Mangulabnan
	 * Date created: 2/21/2018
	 * Last update:
	 ************************************/
	public List<Map<String, String>> executeSelectQuery(String sql) {
		PreparedStatement 	statement = null;
		try {
			statement = conn.prepareStatement(sql);
			ResultSet rs = statement.executeQuery(sql);

			ResultSetMetaData rsmd = rs.getMetaData();
			int col = rsmd.getColumnCount();
			List<Map<String, String>> listMap = new ArrayList<Map<String, String>>();
			while (rs.next()) {
				Map<String, String> map = new HashMap<String, String>();
				for (int i = 1; i <= col; i++) {
					String name = rsmd.getColumnName(i);
					String value = String.valueOf(rs.getObject(name));
					map.put(name, value);
				}
				listMap.add(map);
			}
			statement.close();
			return listMap;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	/***********************************
	 * Execute Update Mysql query
	 * author: Francis Mangulabnan
	 * Date created: 2/22/2018
	 * Last update:
	 ************************************/
	public void executeUpdateQuery(String sql) {
		try {
			PreparedStatement 	statement = null;
			statement = conn.prepareStatement(sql);
			statement.executeUpdate(sql);
			statement.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/***********************************
	 * Execute Update Mysql query
	 * author: Francis Mangulabnan
	 * Date created: 2/22/2018
	 * Last update:
	 ************************************/
	public long executeInsertQuery(String sql) {
		long id = 0;
		try {
			PreparedStatement 	statement = null;
			statement = conn.prepareStatement(sql);
			statement.executeUpdate(sql,Statement.RETURN_GENERATED_KEYS);
			ResultSet rs = statement.getGeneratedKeys();
			if (rs.next()) {
		        id = rs.getLong(1);
		    }
			statement.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return id;
	}
}
