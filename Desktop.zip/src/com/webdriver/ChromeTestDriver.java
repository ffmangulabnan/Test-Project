package com.webdriver;

import java.io.File;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import com.utilities.ConfigDB;

/***********************************
 * Create Chrome driver
 * author: Francis Mangulabnan
 * Date created: 2/21/2018
 * Last update:
 ************************************/
public class ChromeTestDriver {
	public WebDriver webDriver = null;
	private String appPath = new File("").getAbsolutePath();
	private ConfigDB dbConfig = new ConfigDB();
	public ChromeTestDriver(){
		try{
			System.setProperty("webdriver.chrome.driver", appPath + "\\selenium\\driver\\chromedriver.exe");
			ChromeOptions options = new ChromeOptions();
			if(dbConfig.getConfigValue("headless").contentEquals("true")){
				options.addArguments("--headless");
			}
		    options.setAcceptInsecureCerts(true);
		    options.addArguments("ignore-certificate-errors");
		    options.addArguments("--window-size=1325x744");
		    options.addArguments("start-maximized");
			webDriver = new ChromeDriver(options);
			//webDriver.manage().window().maximize();
		}catch(Exception e){
			quitWebDriver();
			webDriver = null;
			e.printStackTrace();
		}
	}
	public WebDriver getWebDriver(){
		return this.webDriver;
	}
	private void quitWebDriver(){
		try{
			webDriver.quit();
		}catch(Exception e){
			
		}
	}
}
