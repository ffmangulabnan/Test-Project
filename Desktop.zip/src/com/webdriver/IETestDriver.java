package com.webdriver;

import java.io.File;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import com.utilities.ConfigDB;

public class IETestDriver {
	public WebDriver webDriver = null;
	private String appPath = new File("").getAbsolutePath();
	private ConfigDB dbConfig = new ConfigDB();
	public IETestDriver() {
		try{
			System.setProperty("webdriver.ie.driver", appPath + "\\selenium\\driver\\IEDriverServer.exe");
			
			InternetExplorerOptions options = new InternetExplorerOptions();
			if(dbConfig.getConfigValue("headless").contentEquals("true")){
				options.setCapability("--headless", true);
			}
			options.setCapability("ignoreZoomSetting", true);
			options.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
			options.setCapability(InternetExplorerDriver.IE_ENSURE_CLEAN_SESSION, true);
			options.setCapability(InternetExplorerDriver.ENABLE_ELEMENT_CACHE_CLEANUP, true);
			options.setCapability(InternetExplorerDriver.NATIVE_EVENTS, false);
		    //options.setAcceptInsecureCerts(true);
		    options.setCapability("ignore-certificate-errors", true);
		    options.setCapability("--window-size=1325x744", true);
		    options.setCapability("start-maximized", true);
			webDriver = new InternetExplorerDriver(options);
			
			webDriver.manage().window().maximize();
			
		}catch(Exception e){
			quitWebDriver();
			webDriver = null;
			e.printStackTrace();
		}
	}
	
	public WebDriver getWebDriver(){
		return this.webDriver;
	}
	private void quitWebDriver(){
		try{
			webDriver.quit();
		}catch(Exception e){
			
		}
	}
}
