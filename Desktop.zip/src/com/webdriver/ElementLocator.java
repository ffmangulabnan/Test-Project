package com.webdriver;

import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.WebDriver;

public class ElementLocator {
	private Logger log;
	private WebDriver webDriver;
	private String defaultBorder;
	public WebElement webElement;
	public String elementError;
	//private String defaultBorderTemp;
	public ElementLocator(Logger logger,WebDriver wd) {
		log = logger;
		webDriver = wd;
	}
	public WebElement findElement(Map<String,String> step) {
		elementError = "";
		WebElement element = null;
		try {
			By by = elementBy(step.get("el_selector"),step.get("el_string"),step.get("el_string_log"));
			String findMethod = step.get("el_find_method");
			int tOut = Integer.parseInt(step.get("el_timeout"));
			WebDriverWait wait = new WebDriverWait(webDriver, tOut);
			//wait until page is ready: 30 seconds timeout
			waitPageIsReady();
			switch (findMethod.toUpperCase().trim()) {
				//wait until visibility of element
				case "VISIBILITYOFELEMENTLOCATED":
					log.info("Finding Element by visibilityOfElementLocated with " + tOut + " seconds timeout.");
					element = wait.until(ExpectedConditions.visibilityOfElementLocated(by));
					break;
				//wait until element to be clickable of element
				case "ELEMENTTOBECLICKABLE":
					log.info("Finding Element by elementToBeClickable with " + tOut + " seconds timeout.");
					element = wait.until(ExpectedConditions.elementToBeClickable(by));
					break;
					//wait until element to be clickable of element
				case "PRESENCEOFELEMENTLOCATED":
					log.info("Finding Element by presenceOfElementLocated " + tOut + " seconds timeout.");
					element = wait.until(ExpectedConditions.presenceOfElementLocated(by));
					break;
				default:
					log.info("Finding Element with " + tOut + " seconds timeout.");
					webDriver.manage().timeouts().implicitlyWait(tOut, TimeUnit.SECONDS);
					element = webDriver.findElement(by);
					break;
			}
			webElement = element;
			if(element!=null) {
				log.info("Successfully found Web Element.");
				highlight();
			}

		} catch(Exception e){
			elementError = e.getMessage().toString();
			log.error("Unable to locate Web Element: " + elementError);
		}

		return element;
	}
	public List<WebElement> findElements(Map<String,String> step) {
		elementError = "";
		List<WebElement> element;
		try {
			By by = elementBy(step.get("el_selector"),step.get("el_string"),step.get("el_string_log"));
			String findMethod = step.get("el_find_method");
			int tOut = Integer.parseInt(step.get("el_timeout"));
			WebDriverWait wait = new WebDriverWait(webDriver, tOut);
			//wait until page is ready: 30 seconds timeout
			waitPageIsReady();
			switch (findMethod.toUpperCase().trim()) {
				//wait until visibility of element
				case "VISIBILITYOFELEMENTLOCATED":
					log.info("Finding Element by visibilityOfElementLocated with " + tOut + " seconds timeout.");
					wait.until(ExpectedConditions.visibilityOfElementLocated(by));
					element = webDriver.findElements(by);
					break;
				//wait until element to be clickable of element
				case "ELEMENTTOBECLICKABLE":
					log.info("Finding Element by elementToBeClickable with " + tOut + " seconds timeout.");
					wait.until(ExpectedConditions.elementToBeClickable(by));
					element = webDriver.findElements(by);
					break;
					//wait until element to be clickable of element
				case "PRESENCEOFELEMENTLOCATED":
					log.info("Finding Element by presenceOfElementLocated " + tOut + " seconds timeout.");
					wait.until(ExpectedConditions.presenceOfElementLocated(by));
					element = webDriver.findElements(by);
					break;
				default:
					log.info("Finding Element with " + tOut + " seconds timeout.");
					webDriver.manage().timeouts().implicitlyWait(tOut, TimeUnit.SECONDS);
					element = webDriver.findElements(by);
					break;
			}
			return element;

		} catch(Exception e){
			elementError = e.getMessage().toString();
			log.error("Unable to locate Web Element: " + elementError);
		}

		return null;
	}
	public By elementBy(String elementSelector, String elementString,String elementStringLog) {
	    By returnedElement = null;
	
	    log.info("Generating By element. Method: " + elementSelector + " Value: " + elementStringLog);
	
		switch (elementSelector.toLowerCase().trim()) {
			//Generate By XPath
			case "xpath":
				returnedElement = By.xpath(elementString);
				break;
			//Generate By CSS Selector
			case "css":
				returnedElement = By.cssSelector(elementString);
				break;
			//Generate By ID
			case "id":
				returnedElement = By.id(elementString);
				break;
			//Generate By Tag
			case "tag":
				returnedElement = By.tagName(elementString);
				break;
			//Generate By Name
			case "name":
				returnedElement = By.name(elementString);
				break;
			//Generate By Class
			case "class":
				returnedElement = By.className(elementString);
				break;
			//Generate By LinkText Block
			case "linktext":
				returnedElement = By.linkText(elementString);
				break;
			default:
				break;
		}
		if(returnedElement.toString().length() > 0) {
			log.info("Successfully created By Object");
		} else {
			log.error("FATAL ERROR: Unable to create By Object!");
		}
		return returnedElement;
	}
	public WebElement visibilityOfElementLocated(int tOut,By by) {
		WebDriverWait wait = new WebDriverWait(webDriver, tOut);
		return wait.until(ExpectedConditions.visibilityOfElementLocated(by));
	}
	/***********************************
	 * Highlight selected element
	 * author: Francis Mangulabnan
	 * Date created: 2/24/2018
	 * Last update:
	 ************************************/
	private void highlight() {
		if (webElement != null) {
			// Highlight the element
			String w = webElement.getCssValue("border-width");
			String s = webElement.getCssValue("border-style");
			String c = webElement.getCssValue("border-color");
			defaultBorder = "try{arguments[0].style.borderStyle='" + s + "';arguments[0].style.borderWidth='" + w
					+ "';arguments[0].style.borderColor='" + c + "';return true;}catch(err){return false;}";
			((JavascriptExecutor) webDriver).executeScript(
					"arguments[0].scrollIntoView(true);arguments[0].style.borderStyle='solid';arguments[0].style.borderWidth='5px';arguments[0].style.borderColor='Red'",webElement);
			((JavascriptExecutor) webDriver).executeScript(
					"arguments[0].scrollIntoView({behavior: \"instant\", block: \"end\", inline: \"nearest\"})",webElement);

		}
	}
	/***********************************
	 * Remove Highlight selected element
	 * author: Francis Mangulabnan
	 * Date created: 2/24/2018
	 * Last update:
	 ************************************/
	public void removeHighlight() {

		if (webElement != null) {
			try {
				// if there already is a highlighted element, unhighlight it
				((JavascriptExecutor) webDriver).executeScript(defaultBorder, webElement);
			} catch (Exception ignored) {
				// the page got reloaded, the element isn't there
			}
		}
	}
	/***********************************
	 * Check page if load status is complete
	 * author: Francis Mangulabnan
	 * Date created: 2/25/2018
	 * Last update:
	 ************************************/
	public void waitPageIsReady() {
		JavascriptExecutor js = (JavascriptExecutor) webDriver;
		for (int i = 0; i < 30; i++) {
			try {
				log.info("check if ready state: " + i);
				// To check page ready state.
				if (js.executeScript("return document.readyState").toString().equals("complete")) {
					log.info("document load complete.");
					return;
				}
				Thread.sleep(1000);
			} catch (Exception e) {
				log.info("check if ready state: Exception " + e.getMessage().toString());
				return;
			}
		}
	}
	public boolean waitUntilElementIsNotDisplayed(Map<String,String> step) {
		By by = elementBy(step.get("el_selector"),step.get("el_string"),step.get("el_string_log"));
		int 		i = 0;
		boolean 	result = false;
		int timeout = Integer.parseInt(step.get("el_timeout"));
		timeout 	= timeout * 10;
		while (i < timeout) {
            try {
                result = new WebDriverWait(webDriver, 5).until(ExpectedConditions.invisibilityOfElementLocated(by));
                if (result == true) {
                	log.info("Element is invisible: " + by.toString());
                    break;
                }

            }catch (Exception ex) {
            	log.error("Waited " + i + " seconds out of " + timeout + " for element to be invisible: " + by.toString());
            }
            i = i + 1;
		}
		return result;
	}
}
