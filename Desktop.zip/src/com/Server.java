package com;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import com.utilities.ConfigDB;
import com.utilities.ConfigUI;
import com.utilities.LogConsole;
import com.utilities.MySqlDB;
import com.utilities.ServerLog;
import com.webdriver.AesCipher;
import com.webdriver.SeleniumTestDriver;



import org.apache.log4j.Logger;
import java.awt.GridBagLayout;
import java.io.File;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JDialog;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import javax.swing.JScrollPane;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JTextArea;
import javax.swing.JLabel;

public class Server {
	private static ConfigDB dbConfig = new ConfigDB();
	private static String appPath = new File("").getAbsolutePath();
	private static String name = dbConfig.getConfigValue("machineName");
    private static MySqlDB mysql;
    public static String serverStatus = "Available";
    private static ServerLog serverLog = new ServerLog(appPath + "/log/server.log");
    private static Logger log = serverLog.getLogger();
    private static volatile boolean run = true;
    private static AesCipher aesCipher = new AesCipher();
    private static Thread serverThread;
	public static void main(String[] args){

		try {
			UIManager.setLookAndFeel("com.jtattoo.plaf.mcwin.McWinLookAndFeel");
		    JButton btnStart = new JButton("Start");
		    JLabel lblStatus = new JLabel("Not Started");
		    
			serverThread = serverThread(btnStart,lblStatus);
			
			
			JFrame frame = new JFrame("Client Server: " + name);
			JFrame.setDefaultLookAndFeelDecorated(true);
			frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
			frame.setSize(800, 400);
			frame.setMinimumSize(new Dimension(800, 400));
			frame.setLocationRelativeTo(null);
			GridBagLayout gridBagLayout = new GridBagLayout();
			gridBagLayout.columnWidths = new int[]{5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
			gridBagLayout.rowHeights = new int[]{5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0};
			gridBagLayout.columnWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
			gridBagLayout.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
			frame.getContentPane().setLayout(gridBagLayout);
			
			GridBagConstraints gbc_btnStart = new GridBagConstraints();
			gbc_btnStart.fill = GridBagConstraints.BOTH;
			gbc_btnStart.gridwidth = 2;
			gbc_btnStart.gridheight = 2;
			gbc_btnStart.insets = new Insets(0, 0, 5, 5);
			gbc_btnStart.gridx = 1;
			gbc_btnStart.gridy = 1;
			frame.getContentPane().add(btnStart, gbc_btnStart);
			btnStart.addActionListener(btnStartActionListener(btnStart,lblStatus));
			
			GridBagConstraints gbc_lblStatus = new GridBagConstraints();
			gbc_lblStatus.gridheight = 2;
			gbc_lblStatus.gridwidth = 20;
			gbc_lblStatus.insets = new Insets(0, 0, 5, 5);
			gbc_lblStatus.gridx = 3;
			gbc_lblStatus.gridy = 1;
			frame.getContentPane().add(lblStatus, gbc_lblStatus);
			
			JButton btnSettings = new JButton("Settings");
			btnSettings.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						ConfigUI dialog = new ConfigUI(dbConfig,aesCipher,btnStart.getText());
						dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
						dialog.setLocationRelativeTo(null);
						dialog.setVisible(true);
					}
				});
			GridBagConstraints gbc_btnSettings = new GridBagConstraints();
			gbc_btnSettings.fill = GridBagConstraints.HORIZONTAL;
			gbc_btnSettings.insets = new Insets(0, 0, 5, 5);
			gbc_btnSettings.gridx = 23;
			gbc_btnSettings.gridy = 1;
			frame.getContentPane().add(btnSettings, gbc_btnSettings);
			
			JButton btnAbout = new JButton("About");
			GridBagConstraints gbc_btnAbout = new GridBagConstraints();
			gbc_btnAbout.fill = GridBagConstraints.HORIZONTAL;
			gbc_btnAbout.insets = new Insets(0, 0, 5, 5);
			gbc_btnAbout.gridx = 23;
			gbc_btnAbout.gridy = 2;
			frame.getContentPane().add(btnAbout, gbc_btnAbout);
			
			JScrollPane scrollPane = new JScrollPane();
			GridBagConstraints gbc_scrollPane = new GridBagConstraints();
			gbc_scrollPane.gridwidth = 23;
			gbc_scrollPane.gridheight = 8;
			gbc_scrollPane.insets = new Insets(0, 0, 5, 5);
			gbc_scrollPane.fill = GridBagConstraints.BOTH;
			gbc_scrollPane.gridx = 1;
			gbc_scrollPane.gridy = 4;
			frame.getContentPane().add(scrollPane, gbc_scrollPane);
			
			JTextArea txtLogs = new JTextArea();
			txtLogs.setLineWrap(true);
			txtLogs.setWrapStyleWord(true);
			txtLogs.setEditable(false);
			txtLogs.setFont(new Font("Calibri Light", Font.PLAIN, 12));
			scrollPane.setViewportView(txtLogs);

			frame.addWindowListener(new java.awt.event.WindowAdapter() {
			    @Override
			    public void windowClosing(java.awt.event.WindowEvent windowEvent) {
			        if (JOptionPane.showConfirmDialog(frame, 
			            "Are you sure to exit this server", "Server Exit", 
			            JOptionPane.YES_NO_OPTION,
			            JOptionPane.QUESTION_MESSAGE) == JOptionPane.YES_OPTION){
			        	try {
			        		mysql = new MySqlDB();
							if(mysql != null && mysql.conn!=null && !mysql.conn.isClosed()){
								mysql.updateMachineStatus(name, "offline");
								mysql.conn.close();
							}
						} catch (SQLException e) {}
			            System.exit(0);
			        }
			    }
			});
			new LogConsole(txtLogs);
			frame.setVisible(true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.exit(0);
		}
	}
	/***********************************
	 * validate if server machine is exist else create new
	 * author: Francis Mangulabnan
	 * Date created: 2/11/2018
	 * Last update:
	 ************************************/
	public static boolean validateMachine(Logger log){
		try {
			name = dbConfig.getConfigValue("machineName");
			List<Map<String, String>> machine = mysql.getMachine(name);
			if(machine.size() > 0) {
				String jarKey = aesCipher.decrypt(dbConfig.getConfigValue("machineKey")).toString();
				String serverKey = aesCipher.decrypt(machine.get(0).get("password")).toString();
				if(jarKey.contentEquals(serverKey)){
					if(mysql.getMachineStatus(name).contentEquals("offline")){
						mysql.updateMachineStatus(name,"online");
						log.info("Machine:" + name);
						log.info("Status: online");
						return true;
					} else {
						log.error("Name already exist/online, Please set new Name in the settings");
						mysql.conn.close();
						JOptionPane.showMessageDialog(null, "Name already exist/online!", "Error",JOptionPane.ERROR_MESSAGE);
						return false;
					}
				} else {
					log.error("Invalid Machine Key, Change key/set new Name in the settings");
					JOptionPane.showMessageDialog(null, "Invalid Machine Key, Change key/set new Name in the settings", "Error",JOptionPane.ERROR_MESSAGE);
					mysql.conn.close();
					return false;
				}
			} else {
				mysql.conn.close();
				log.info("Machine "+name+" not exist, please contact you administrator to add your client server name");
				JOptionPane.showMessageDialog(null, "Machine "+name+" not exist, please contact you administrator to add your client server name", "Error", JOptionPane.ERROR_MESSAGE);
				return false;
			}
		}catch(Exception e) {}
		return false;
	}

	/***********************************
	 *	Start server
	 * author: Francis Mangulabnan
	 * Date created: 6/16/2018
	 * Last update:
	 ************************************/
	public static void startServer(JButton btnStart,JLabel lblStatus){
		try {
			log.info("server "+ name + " has started.");
			log.info("Date:" + new Date());
			while(true) {
				if(run){
					try {
						lblStatus.setText("Running");
						//log.info("Fetching TestSuite in Queue...");
						List<Map<String, String>> testSuite = mysql.getTestSuiteInQueue(name);
						if(testSuite.size() > 0) {
							String projId = testSuite.get(0).get("project_id");
							String projDb = mysql.getProjectDBName(projId);
							String runId = testSuite.get(0).get("run_id");
							String qId = testSuite.get(0).get("id");
							log.info("TestSuite found: " + runId);
							log.info("Project: "  + projDb);
							log.info("Scheduled:" + testSuite.get(0).get("scheduled"));
							if(testSuite.get(0).get("scheduled").equalsIgnoreCase("no")) {
								log.info("Deleting TestSuite in Queue... ");
								mysql.deleteQueue(qId);
								log.info("Deleting TestSuite in Queue [Done]");
							}
							log.info("SeleniumTestDriver has started." );
					 		log.info("Project Database name: " + projDb);
					 		new SeleniumTestDriver(projDb,runId,log,mysql,testSuite.get(0).get("scheduled"));
					 		log.info("SeleniumTestDriver [DONE]");	
							
						} else {
							log.info("No TestSuite found in Queue...");
						}
						
						Thread.sleep(9000);
					} catch (InterruptedException e1) {
						stopServer();
						log.info("Server Stopped");
					} catch(Exception e) {
						stopServer();
						e.printStackTrace();
						log.error("Exception error! : " + e.getMessage());
					}	
				}
				Thread.sleep(1000);
			}

		} catch (Exception e) {
			stopServer();
			//e.printStackTrace();
			log.error("Server Stopped" + e.getMessage());
			//JOptionPane.showMessageDialog(null, e.getMessage(), "Stopped",JOptionPane.ERROR_MESSAGE);
			btnStart.setText("Start");
			lblStatus.setText("Stopped");
		}	
	}
	
	public static ActionListener btnStartActionListener(JButton btnStart,JLabel lblStatus) {
		ActionListener action = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String startText = btnStart.getText();
				
				try {
					if (startText.contentEquals("Start")) {
						btnStart.setEnabled(false);
						lblStatus.setText("Connecting...");
						mysql = new MySqlDB();
						lblStatus.setText("Starting...");
						log.info("Server State:  "+ serverThread.getState().toString());
						if(serverThread.getState().toString().contentEquals("NEW")){
							if(mysql.conn==null){
								log.error("Database connection error!");
								btnStart.setText("Start");
								lblStatus.setText("Not Started");
								btnStart.setEnabled(true);
								JOptionPane.showMessageDialog(null, "Database connection error!", "Error",JOptionPane.ERROR_MESSAGE);
								return;
							}
							if(!validateMachine(log)){
								btnStart.setText("Start");
								lblStatus.setText("Not Started");
								btnStart.setEnabled(true);
								return;
							}
							
							serverThread.start();	
						} else if(serverThread.getState().toString().contentEquals("TERMINATED")){
							if(!validateMachine(log)){
								btnStart.setText("Start");
								lblStatus.setText("Not Started");
								btnStart.setEnabled(true);
								return;
							}
							serverThread = serverThread(btnStart,lblStatus);
							serverThread.start();	
						} else {
							if(!validateMachine(log)){
								btnStart.setText("Start");
								lblStatus.setText("Not Started");
								btnStart.setEnabled(true);
								return;
							}
							resumeServer();
							log.info("server "+ name + " resumed.");
						}
						btnStart.setText("Stop");
						btnStart.setEnabled(true);
						
					} else if (startText.contentEquals("Stop")) {
						serverThread.interrupt();
						log.info("server "+ name + " has stopped.");
						//mysql.updateMachineStatus(name, "offline");
						btnStart.setText("Start");
						lblStatus.setText("Stopped");
						try {
							if(mysql!=null) {
								mysql.conn.close();
							}
						} catch (SQLException e1) {}
					}
				} catch (Exception err) {
					err.printStackTrace();
					JOptionPane.showMessageDialog(null, "Start Exception", "Error", JOptionPane.ERROR_MESSAGE);
				}

			}
		};
		return action;
	}
	private static void stopServer(){
		run = false;
		try {
			mysql = new MySqlDB();
			if(mysql != null && !mysql.conn.isClosed()){
				System.out.println("isclosed" + mysql.conn.isClosed());
				mysql.updateMachineStatus(name, "offline");
				mysql.conn.close();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	private static void resumeServer(){
		run = true;
	}
	private static Thread serverThread(JButton btnStart,JLabel lblStatus){
		return new Thread(new Runnable() {
			public void run() {
				try {
					startServer(btnStart,lblStatus);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
	}
	
}
